# Snake
Classic 2D game for LLP

## build instructions
Use Visual Studio 2017 Version 15.4.2. Once you have downloaded the repositry run the snake.sln inside of the "projects" folder.
After this use the run button or CTRL+F5
## gameplay
Use WASD to move around the screen and avoid colliding with yourself while collecting fruit, there are also fruit that may aid or make 
things more difficult i.e changing your speed
## design decisions
I have decided to allow the snake to go from one side of the screen to the other. This allows for more flexible movement and after a short 
duration the snake can actually reach the lenght/width of the screen. This adds end game depth as what could have been considered helpful
can actually result in a game over if your not careful.

I have added two powerups a cold and speed fruit. These will either increase or decrease your speed and if not eaten will randomly respawn. This means if your late into the game and don't want to eat the speed fruit for increased speed making it harder, then you can't
avoid it forever especially if it spawns directly infront of you.

For a look into my process a link to my blog:
https://jackw8335.github.io/blog/
