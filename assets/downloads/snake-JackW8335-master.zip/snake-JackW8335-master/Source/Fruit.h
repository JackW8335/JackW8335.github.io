#include <Engine\Sprite.h>
#ifndef FRUIT_H
#define FRUIT_H


class Fruit
{
public:
	Fruit();
	~Fruit();
	Fruit(int, int);
	void setSprite(ASGE::Sprite* fruit);
	ASGE::Sprite* getSprite();
	float getFruitX();
	float getFruitY();
	void setFruitXY(float, float);
	void randFruit();
	bool checkFruit(float player_x, float player_y);

private:
	float fruit_x;
	float fruit_y;
	ASGE::Sprite* fruit;
	
};
#endif