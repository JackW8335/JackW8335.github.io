#pragma once
#ifndef POWERFRUIT_H
#define POWERFRUIT_H

#include <Fruit.h>



class PowerFruit : public Fruit
{
public:
	PowerFruit();
	~PowerFruit();
	PowerFruit(int, int);
	int getDuration();
private:
	int duration = 50;
};

#endif