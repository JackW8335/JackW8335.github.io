#pragma once
#include <string>
#include <Engine/OGLGame.h>
#include "PlayerBody.h"
#include "Player.h"
#include "Fruit.h"
#include "PowerFruit.h"
#include <time.h>
struct GameFont;

/**
*  SnakeGame. An OpenGL Game based on ASGE.
*/

class SnakeGame :
	public ASGE::OGLGame
{
public:
	SnakeGame();
	~SnakeGame();
	void drawSprite();
	void processGameActions();
	virtual bool init() override;
	void initSprite();
	void powerFruitAction();
	void fruitSelection();
	void coldFruit();
	void speedFruit();
private:
	ASGE::Sprite* player_sprite = nullptr;
	ASGE::Sprite* fruit_sprite = nullptr;
	ASGE::Sprite* body_sprite = nullptr;
	ASGE::Sprite* power_fruit_sprite = nullptr;
	PlayerBody* bodyCount = nullptr;
	Player* player = nullptr;
	Fruit* fruit = nullptr;
	PowerFruit* power_fruit = nullptr;
	void input(ASGE::SharedEventData data) const;
	bool shouldExit() const;
	int rate = 20;
	int score = 0;
	int body_size = 0;
	double delta_time = 0.0;
	int cooldown=0;
	bool power_active = false;
	int fruit_id;
	// Inherited via OGLGame
	virtual void update(const ASGE::GameTime &) override;
	virtual void render(const ASGE::GameTime &) override;

	int  callback_id = -1;             /**< Input Callback ID. The callback ID assigned by the game engine. */
	bool exit = false;                 /**< Exit boolean. If true the game loop will exit. */
	ASGE::Sprite* sprite = nullptr;    /**< Sprite Object. The background sprite. */
	//ASGE::Sprite* snake = nullptr;

};

