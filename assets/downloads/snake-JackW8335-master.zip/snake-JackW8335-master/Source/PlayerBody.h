#include <Engine\Sprite.h>

class PlayerBody
{
public:
	PlayerBody();
	~PlayerBody();

	float getBodyX();
	float getBodyY();
	ASGE::Sprite* getSprite();
	void setSprite(ASGE::Sprite* body);
	void updateBody(float player_x, float player_y);
	float getPreviousBodyX();
	float getPreviousBodyY();

private:
	float previous_body_x;
	float previous_body_y;
	float body_x;
	float body_y;
	ASGE::Sprite* body;

};