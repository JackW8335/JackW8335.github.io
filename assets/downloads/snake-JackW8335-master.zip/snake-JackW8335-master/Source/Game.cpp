#include <Engine/Keys.h>
#include <Engine/Input.h>
#include <Engine/InputEvents.h>
#include <Engine/Sprite.h>

#include "Actions.h"
#include "Constants.h"
#include "Game.h"
#include "GameFont.h"
#include <string>
#include <iostream>




/**
*   @brief   Default Constructor.
*/
SnakeGame::SnakeGame()
{
	fruit_id = 1;
}
/**
*   @brief   Destructor.
*   @details Remove any non-managed memory and callbacks.
*/
SnakeGame::~SnakeGame()
{
	this->inputs->unregisterCallback(callback_id);

	if (sprite)
	{
		delete sprite;
		sprite = nullptr;
	}

	for (auto& font : GameFont::fonts)
	{
		delete font;
		font = nullptr;
	}
	delete player;
	delete player_sprite;
	delete fruit;
	delete fruit_sprite;
	delete[] bodyCount;
	delete body_sprite;
	delete power_fruit;
	delete power_fruit_sprite;
	
	
	
	
}


/**
*   @brief   Initialises the game.
*   @details The game window is created and all assets required to
			 run the game are loaded. The input callback should also
			 be set in the initialise function.
*   @return  True if the game initialised correctly.
*/
bool SnakeGame::init()
{
	srand(time(NULL));
	width = WINDOW_WIDTH;
	height = WINDOW_HEIGHT;

	if (!initAPI())
	{
		return false;
	}




	renderer->setWindowTitle("Snake - Game 2");
	renderer->setClearColour(ASGE::COLOURS::BLACK);
	renderer->setSpriteMode(ASGE::SpriteSortMode::IMMEDIATE);

	toggleFPS();

	// input callback function
	callback_id = this->inputs->addCallbackFnc(ASGE::EventType::E_KEY, &SnakeGame::input, this);

	// load fonts we need
	GameFont::fonts[0] = new GameFont(
		renderer->loadFont("..\\..\\Resources\\Fonts\\Comic.ttf", 42), "default", 42);

	if (GameFont::fonts[0]->id == -1)
	{
		return false;
	}

	// load snake background sprite
	sprite = renderer->createRawSprite();
	sprite->position[0] = -50;
	sprite->position[1] = 0;
	sprite->scalar = 1.15f;

	if (!sprite->loadTexture("..\\..\\Resources\\Textures\\snake-1200x627.png"))
	{
		return false;
	}

	player = new Player(600, 600);
	fruit = new Fruit(500, 500);
	bodyCount = new PlayerBody[100];
	power_fruit = new PowerFruit(100, 100);
	fruit->randFruit();
	game_action = GameAction::NONE;

	initSprite();
	return true;
}

void SnakeGame::initSprite()
{
	//initialises all the sprites with textures and locations

	player_sprite = renderer->createRawSprite();
	player_sprite->position[0] = player->getPositionX();
	player_sprite->position[1] = player->getPositionY();
	player_sprite->scalar = 1.0f;

	if (!player_sprite->loadTexture("..\\..\\Resources\\Textures\\green_square.png"))
	{
		player_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}
	player->setSprite(player_sprite);

	//Check to see that the fruit has been eaten before spawning another
	if (fruit->checkFruit(player->getPositionX(), player->getPositionY()))
	{
		fruit->randFruit();

		if (body_size < 40)
		{
			body_size++;
		}
	}
	fruit_sprite = renderer->createRawSprite();
	fruit_sprite->position[0] = fruit->getFruitX();
	fruit_sprite->position[1] = fruit->getFruitY();
	fruit_sprite->scalar = 1.0f;

	if (!fruit_sprite->loadTexture("..\\..\\Resources\\Textures\\fruit.png"))
	{
		fruit_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}
	fruit->setSprite(fruit_sprite);



	body_sprite = bodyCount[0].getSprite();
	body_sprite = renderer->createRawSprite();
	bodyCount[0].updateBody(player->getPreviousPositionX(), player->getPreviousPositionY());
	body_sprite->position[0] = player->getPreviousPositionX();
	body_sprite->position[1] = player->getPreviousPositionY();
	body_sprite->scalar = 1.0f;

	if (!body_sprite->loadTexture("..\\..\\Resources\\Textures\\green_square.png"))
	{
		body_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}
	bodyCount[0].setSprite(body_sprite);

	power_fruit->randFruit();
	power_fruit_sprite = renderer->createRawSprite();
	power_fruit_sprite->position[0] = power_fruit->getFruitX();
	power_fruit_sprite->position[1] = power_fruit->getFruitY();
	power_fruit_sprite->scalar = 1.0f;

}

void SnakeGame::powerFruitAction()
{
	
	switch (fruit_id)
	{
		{
	case 1:
		coldFruit();
		break;
		}
	case 2:
	{
		speedFruit();
		break;
	}
	}
}

void SnakeGame::fruitSelection()
{
		fruit_id = rand() % 2 + 1;
}

void SnakeGame::coldFruit()
{
	if (!power_fruit_sprite->loadTexture("..\\..\\Resources\\Textures\\cold_fruit.png"))
	{
		power_fruit_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}
	power_fruit->setSprite(power_fruit_sprite);

	//if you collide with the cold fruit spawn it out of site and reduce player speed 
	if (power_fruit->checkFruit(player->getPositionX(), player->getPositionY()))
	{
		rate = 10;
		power_fruit_sprite = power_fruit->getSprite();
		power_fruit->setFruitXY(-40, -40);
		power_fruit_sprite->position[0] = -40;
		power_fruit_sprite->position[1] = -40;
		score++;
		power_active = true;
		cooldown = 0;
	}
	cooldown += delta_time;
	if (cooldown > power_fruit->getDuration() && power_active)
	{
		rate = 20;
		power_active = false;
	}
	//spawn a new fruit every 10 seconds 1 second is 16.66667 so 166 is around 10
	else if (cooldown >= 166)
	{
		fruitSelection();
		power_fruit->randFruit();
		power_fruit_sprite->position[0] = power_fruit->getFruitX();
		power_fruit_sprite->position[1] = power_fruit->getFruitY();
		cooldown = 0;
	}
}

void SnakeGame::speedFruit()
{
	if (!power_fruit_sprite->loadTexture("..\\..\\Resources\\Textures\\speed_fruit.png"))
	{
		power_fruit_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}
	power_fruit->setSprite(power_fruit_sprite);

	if (power_fruit->checkFruit(player->getPositionX(), player->getPositionY()))
	{
		rate = 30;
		power_fruit_sprite = power_fruit->getSprite();
		power_fruit->setFruitXY(-40, -40);
		power_fruit_sprite->position[0] = -40;
		power_fruit_sprite->position[1] = -40;
		score++;
		power_active = true;
		cooldown = 0;
	}
	cooldown += delta_time;
	if (cooldown > 166 && power_active)
	{
		rate = 20;
		power_active = false;
	}
	//spawn a new fruit every 10 seconds 1 second is 16.66667 so 166 is around 10
	else if (cooldown >= 166)
	{
		fruitSelection();
		power_fruit->randFruit();
		power_fruit_sprite->position[0] = power_fruit->getFruitX();
		power_fruit_sprite->position[1] = power_fruit->getFruitY();
		cooldown = 0;
	}
}



/**
*   @brief   Should the game exit?
*   @details Has the renderer terminated or the game requesting to exit?
*   @return  True if the game should exit
*/
bool SnakeGame::shouldExit() const
{
	return (renderer->exit() || this->exit);
}


/**
*   @brief   Processes any key inputs and translates them to a GameAction
*   @details This function is added as a callback to handle the game's
			 input. Key presseses are translated in to GameActions which
			 are then processed by the main game loop.
*   @param   key is the key the action relates to
*   @param   action whether the key was released or pressed
*   @return  void
*/
void SnakeGame::input(ASGE::SharedEventData data) const
{
	auto key_event = static_cast<ASGE::KeyEvent*>(data.get());
	auto action = key_event->action;
	auto key = key_event->key;

	if (action == ASGE::KEYS::KEY_PRESSED)
	{
		player->setKey(key);

		if (key == ASGE::KEYS::KEY_ESCAPE)
		{
			game_action = GameAction::EXIT;
		}
		if (key == ASGE::KEYS::KEY_SPACE)
		{
			game_action = GameAction::PLAY;
		}
	}
}
/**
*   @brief   Updates the scene
*   @details Prepares the renderer subsystem before drawing the
			 current frame. Once the current frame is has finished
			 the buffers are swapped accordingly and the image shown.
*   @return  void
*/
void SnakeGame::update(const ASGE::GameTime &time)
{

	delta_time += time.delta_time.count() / (1000.0 / rate);
	// gamepad input is polled
	auto& gamepad = inputs->getGamePad(0);
	if (gamepad.is_connected &&
		gamepad.buttons[1])
	{
		game_action = GameAction::EXIT;
	}


	// should we terminate the game?
	if (shouldExit())
	{
		signalExit();
	}
	processGameActions();

	if (game_action == GameAction::PLAY)
	{
		if (delta_time >= 1)
		{
			player->updatePosition(delta_time);
			drawSprite();
			delta_time--;
		}
	}
	// run the game loop
	for (int i = 1; i <= body_size; i++)
	{
		//checks for player collision with its own body as this is the only win/loss condition
		if (player->getPositionX() <= bodyCount[i].getBodyX() + 39 && player->getPositionX() >= bodyCount[i].getBodyX()
			&& player->getPositionY() <= bodyCount[i].getBodyY() + 39 && player->getPositionY() >= bodyCount[i].getBodyY())
		{
			game_action = GameAction::GAME_OVER;
		}
	}

}


/**
*   @brief   Renders the scene
*   @details Renders all the game objects to the current frame.
			 Once the current frame is has finished the buffers are
			 swapped accordingly and the image shown.
*   @return  void
*/
void SnakeGame::render(const ASGE::GameTime &)
{
	//renders all my sprites 
	// all the get sprite calls are making the sprites in game equal to the sprites in my classes
	renderer->setFont(GameFont::fonts[0]->id);
	if (sprite != nullptr)
	{
		renderer->renderSprite(*sprite);
	}
	if (game_action == GameAction::PLAY || game_action == GameAction::GAME_OVER)
	{
		if (player->getSprite() != nullptr)
		{
			renderer->renderSprite(*player->getSprite());
		}

		if (fruit->getSprite() != nullptr)
		{
			renderer->renderSprite(*fruit->getSprite());
		}

		if (power_fruit->getSprite() != nullptr)
		{
			renderer->renderSprite(*power_fruit->getSprite());
		}

		for (int i = 0; i <= body_size; i++)
		{
			if (bodyCount[i].getSprite() != nullptr)
			{
				renderer->renderSprite(*bodyCount[i].getSprite());
			}
		}
		//Renders the score equal to number of fruits eaten
		std::string score_counter = std::to_string(score);
		const char * c = score_counter.c_str();

		renderer->renderText(c, 0, 720, 1.0, ASGE::COLOURS::DARKORANGE);
	}


	if (game_action == GameAction::NONE)
	{
		renderer->renderText("\nPRESS SPACE TO START", 360, 360, 1.0, ASGE::COLOURS::DARKORANGE);
	}

	if (game_action == GameAction::GAME_OVER)
	{
		{
			renderer->renderText("\n GAME OVER \nPRESS ESCAPE TO EXIT", 360, 360, 1.0, ASGE::COLOURS::DARKORANGE);

		}
	}

}



void SnakeGame::drawSprite()
{
	player_sprite = player->getSprite();
	player_sprite->position[0] = player->getPositionX();
	player_sprite->position[1] = player->getPositionY();


	//Check to see that the fruit has been eaten before spawning another
	if (fruit->checkFruit(player->getPositionX(), player->getPositionY()))
	{
		score++;
		fruit->randFruit();
		if (body_size < 100)
		{
			body_size++;
			for (int i = body_size; i <= body_size; i++)
			{
				body_sprite = bodyCount[i].getSprite();
				body_sprite = renderer->createRawSprite();
				bodyCount[i].updateBody(bodyCount[i - 1].getPreviousBodyX(), bodyCount[i - 1].getPreviousBodyY());
				body_sprite->position[0] = bodyCount[i - 1].getPreviousBodyX();
				body_sprite->position[1] = bodyCount[i - 1].getPreviousBodyY();
				bodyCount[i].setSprite(body_sprite);

				if (!body_sprite->loadTexture("..\\..\\Resources\\Textures\\green_square.png"))
				{
					body_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
				}
			}
		}
	}
	fruit_sprite->position[0] = fruit->getFruitX();
	fruit_sprite->position[1] = fruit->getFruitY();


	body_sprite = bodyCount[0].getSprite();
	bodyCount[0].updateBody(player->getPreviousPositionX(), player->getPreviousPositionY());
	body_sprite->position[0] = player->getPreviousPositionX();
	body_sprite->position[1] = player->getPreviousPositionY();


	for (int i = 1; i <= body_size; i++)
	{
		body_sprite = bodyCount[i].getSprite();
		bodyCount[i].updateBody(bodyCount[i - 1].getPreviousBodyX(), bodyCount[i - 1].getPreviousBodyY());
		body_sprite->position[0] = bodyCount[i - 1].getPreviousBodyX();
		body_sprite->position[1] = bodyCount[i - 1].getPreviousBodyY();
	}
	//if a player eats the power fruit then the snake slows down for 5 seconds
	powerFruitAction();
}


/**
*   @brief   Processes the next game action
*   @details Uses the game action that was a direct result of
*            user input. It allows input to processed in a different
			 thread and the game actions performed in the main thread.
*   @return  void
*/
void SnakeGame::processGameActions()
{

	if (game_action == GameAction::EXIT)
	{
		this->exit = true;
	}

	if (game_action == GameAction::PLAY)
	{
		if (!sprite->loadTexture("..\\..\\Resources\\Textures\\background.png"))
		{
			sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
		}
	}
}




