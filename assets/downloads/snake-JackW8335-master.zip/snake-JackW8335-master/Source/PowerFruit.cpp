#include "PowerFruit.h"



PowerFruit::PowerFruit()
{
	
}


PowerFruit::~PowerFruit()
{
	
}

PowerFruit::PowerFruit(int, int)
{
}


int PowerFruit::getDuration()
{
	return duration;
}


