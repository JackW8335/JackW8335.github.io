#include "PlayerBody.h"


PlayerBody::PlayerBody()
{
	
}

PlayerBody::~PlayerBody()
{
	
}

float PlayerBody::getBodyX()
{
	return body_x;
}

float PlayerBody::getBodyY()
{
	return body_y;
}


ASGE::Sprite* PlayerBody::getSprite()
{
	return body;
}

void PlayerBody::setSprite(ASGE::Sprite * body)
{
	this->body = body;
}

void PlayerBody::updateBody(float player_x, float player_y)
{
	previous_body_x = body_x;
	previous_body_y = body_y;
	body_x = player_x;
	body_y = player_y;
}


float PlayerBody::getPreviousBodyX()
{
	return previous_body_x;
}

float PlayerBody::getPreviousBodyY()
{
	return previous_body_y;
}







