#pragma once
#include <Engine/Sprite.h>
#include <Engine\GameTime.h>
class Player
{
public:
	Player();
	~Player();

	Player(int position_x, int position_y);
	int getPositionX();
	int getPositionY();
	int getPreviousPositionX();
	int getPreviousPositionY();
	ASGE::Sprite* getSprite();
	void setSprite(ASGE::Sprite* sprite);
	void updatePosition(float timeTrack);
	void setKey(int key);
	int getKey();

private:
	int previous_key;
	float speed;
	float position_x;
	float position_y;
	int previous_position_x;
	int previous_position_y;
	int key;
	ASGE::Sprite* sprite = nullptr;
};

