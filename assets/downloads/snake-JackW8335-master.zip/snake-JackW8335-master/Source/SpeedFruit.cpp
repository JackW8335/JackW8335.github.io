#include "SpeedFruit.h"



SpeedFruit::SpeedFruit()
{
}


SpeedFruit::~SpeedFruit()
{
}
