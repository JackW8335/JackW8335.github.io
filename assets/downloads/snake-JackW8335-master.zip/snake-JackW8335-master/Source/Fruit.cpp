#include "Fruit.h"
#include <time.h>


Fruit::Fruit()
{
	srand(time(NULL));
}


Fruit::~Fruit()
{
	
}

Fruit::Fruit(int position_x, int position_y)
{

}

void Fruit::setSprite(ASGE::Sprite * fruit)
{
	this->fruit = fruit;

}

ASGE::Sprite* Fruit::getSprite()
{
	return fruit;
}

float Fruit::getFruitX()
{
	return fruit_x;
}

float Fruit::getFruitY()
{
	return fruit_y;
}

void Fruit::setFruitXY(float x, float y)
{
	fruit_x = x;
	fruit_y = y;
}

void Fruit::randFruit()
{
	//resolution of the screen - size of the fruit
	//to stop it spawning abit of screen
	fruit_x = rand() % 1240 + 1; 
	fruit_y = rand() % 680 + 1;
}

bool Fruit::checkFruit(float player_x, float player_y)
{
	if (player_x <= fruit_x + 40 && player_x >= fruit_x - 40 && player_y <= fruit_y + 40 && player_y >= fruit_y - 40)
	{
		return true;
	}
	return false;
}