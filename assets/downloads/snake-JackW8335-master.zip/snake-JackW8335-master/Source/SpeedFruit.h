#pragma once
#include "c:\Users\Jack\Documents\GitHub\snake-JackW8335\Source\Fruit.h"
class SpeedFruit :
	public Fruit
{
public:
	SpeedFruit();
	~SpeedFruit();
};

