#include "Player.h"
#include <Engine\Keys.h>
#include <Engine\GameTime.h>



Player::Player()
{

}


Player::~Player()
{
	
}

Player::Player(int position_x, int position_y)
{
	speed = 40.0;
	this->position_x = position_x;
	this->position_y = position_y;
}


void Player::updatePosition(float timeTrack)
{
	previous_position_x = position_x;
	previous_position_y = position_y;

	float delta_speed = speed*timeTrack;

	if (timeTrack > 1)
	{
		delta_speed = speed*timeTrack;
	}


	switch (key)
	{
	case ASGE::KEYS::KEY_W:
	{
		if (previous_key != ASGE::KEYS::KEY_S)
		{
			position_y -= delta_speed;
			previous_key = ASGE::KEYS::KEY_W;
		}

		if (position_y < -20.0f)
		{
			position_y = 680.0f;
		}
		break;
	}

	case ASGE::KEYS::KEY_A:
	{
		if (previous_key != ASGE::KEYS::KEY_D)
		{
			position_x -= delta_speed;
			previous_key = ASGE::KEYS::KEY_A;
		}
		if (position_x < -10.0f)
		{
			position_x = 1240.0f;
		}
		
		break;
	}

	case ASGE::KEYS::KEY_S:
	{
		if ( previous_key != ASGE::KEYS::KEY_W)
		{
			position_y += delta_speed;
			previous_key = ASGE::KEYS::KEY_S;
		}
		if (position_y > 720.0f)
		{
			position_y = 0.0f;
		}
		break;
	}

	case ASGE::KEYS::KEY_D:
	{
		if (previous_key != ASGE::KEYS::KEY_A)
		{
			position_x += delta_speed;
			previous_key = ASGE::KEYS::KEY_D;
		}
		if (position_x > 1280.0f)
		{
			position_x = 0.0f;
		}
		break;
	}
	}
	key = previous_key;
}



int Player::getPositionX()
{
	return position_x;
}

int Player::getPositionY()
{
	return position_y;
}

int Player::getPreviousPositionX()
{
	return previous_position_x;
}

int Player::getPreviousPositionY()
{
	return previous_position_y;
}

void Player::setKey(int key)
{
	this->key = key;
}

int Player::getKey()
{
	return key;
}

ASGE::Sprite* Player::getSprite()
{
	return sprite;
}

void Player::setSprite(ASGE::Sprite * sprite)
{
	this->sprite = sprite;

}

