#pragma once
#include "Fruit.h"
class SpeedFruit : public Fruit
{
public:
	SpeedFruit();
	~SpeedFruit();
	int getDuration();
	SpeedFruit(int, int);
private:
	int duration;
};

