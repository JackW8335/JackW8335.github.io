#pragma once

#include <Engine/Sprite.h>

class Obstacle
{
public:
	Obstacle();
	~Obstacle();
	Obstacle(double, double);
	double getPositionX();
	double getPositionY();
	ASGE::Sprite* getSprite();
	int getWidth();
	int getHeight();
	void setSprite(ASGE::Sprite* sprite);

	bool checkCollision(double,double);
	bool safeSpawn(double position_x, double position_y);
	void setPosition(int,int);
private:
	double tileset_x;
	double tileset_y;
	double width;
	double height;
	double position_x;
	double position_y;
	ASGE::Sprite* obstacle_sprite = nullptr;
};

