#pragma once

class Level
{
public:
	Level::Level() = default;
	Level::~Level() =  default;
	void generateRandomLevels(int obstacleNumber, int x, int y);

private:

};

