#pragma once
#include <atomic>
#include <time.h>
#include <Engine\OGLGame.h>
#include <Engine\Sprite.h>
#include "Actions.h"
#include "Player.h"
#include "Obstacle.h"
#include "Enemy.h"


namespace ASGE {
	struct GameTime;
}

/**
*  EndlessGame is the main entrypoint into the game.
*  It is based on the ASGE framework and makes use of
*  the OGLGame class. This allows the rendering and
*  input initialisation to be handled easily and without
*  fuss. The game logic responsible for updating and 
*  rendering the game starts here. 
*/
class EndlessGame : 
	public ASGE::OGLGame
{
public:

	/**
	*  Default constructor for game.
	*/
	EndlessGame() = default;
	
	/**
	*  Destructor for game.
	*  Make sure to clean up any dynamically allocated
	*  memory inside the game's destructor. For example
	*  game fonts need to be deallocated. 
	*/
	~EndlessGame();

	/**
	*  The initialisation of the game.
	*  Both the game's initialisation and the API setup
	*  should be performed inside this function. Once the 
	*  API is up and running the input system can register
	*  callback functions when certain events happen. 
	*/
	virtual bool init() override;

	void initSprite();
	void generateMap();
	void generateEnemies();
	void enemyCollision();
	void EndlessMap();
	void randomTileSet();
	void makeStairs();
	void makeCorridor();
	void collisions();
	void processGameActions();
	void highScoreTracker();
	void gameOver();
	void restart();
	void gameMenu();
	void drawSprite();
	bool shouldExit() const;
private:
	int fileScore = 0;
	int score;
	ASGE::Sprite* floor = nullptr;
	int previous_position_x;
	int key;
	int previous_key;
	bool exit = false;
	Player* player = nullptr;
	Obstacle* obstacle = nullptr;
	Enemy* enemy = nullptr;
	int obstacle_number = 5;
	int number_of_enemies = 0;
	int enemy_cap = 5;
	void levelMovement();

	ASGE::Sprite* background = nullptr;
	ASGE::Sprite* player_sprite = nullptr;
	ASGE::Sprite* obstacle_sprite = nullptr;
	ASGE::Sprite* enemy_sprite = nullptr;
	double delta_time = 0.0;
	/**
	*  The simulation for the game.
	*  The objects in the game need to updated or simulated
	*  over time. Use this function to decouple the render
	*  phases from the simulation.
	*  @param us The delta time between frames and running time
	*  @see GameTime
	*/
	virtual void update(const ASGE::GameTime & us) override;
	
	/**
	*  The rendering of the game.
	*  This function gets called after the game world has 
	*  been updated. Ensure all your objects are in a sane
	*  simulated state before calling this function.
	*  @param us The delta time between frames and running time
	*  @see GameTime
	*/
	virtual void render(const ASGE::GameTime & us) override;
	
	/**
	*  The key handling function for the game.
	*  Key inputs will be delivered and handled within this function.
	*  Make a decision whether to process the input immediately
	*  or whether to generate a queue of actions that are then
	*  processed at the beginning of the game update loop.
	*  @param data They key event and its related data. 
	*  @see SharedEventData
	*/
	void keyHandler(ASGE::SharedEventData data);

private:
	int key_handler_id = -1;  /**< Input Callback ID. The callback ID assigned by the game engine. */
	
};