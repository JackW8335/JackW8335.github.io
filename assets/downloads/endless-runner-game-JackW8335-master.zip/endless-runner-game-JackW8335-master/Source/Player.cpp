#include "Player.h"

Player::Player()
{


}

Player::~Player()
{
}

Player::Player(int position_x, int position_y)
{
	speed = 30;
	acceleration_y = 1.0;
	force = 50.0;
	stop_force = -force;
	this->position_x = position_x;
	this->position_y = position_y;
	floor_y = position_y;
}

double Player::getPositionX()
{
	return position_x;
}

double Player::getPositionY()
{
	return position_y;
}

void Player::setPositionX(double position_x)
{
	this->position_x = position_x;
}

void Player::setPositionY(double position_y)
{
	this->position_y = position_y;
}

void Player::setKey(int key)
{
	this->key = key;
}

ASGE::Sprite* Player::getSprite()
{
	return sprite;
}

void Player::setSprite(ASGE::Sprite * sprite)
{
	this->sprite = sprite;
}

void Player::playerMovement()
{

	if (key == ASGE::KEYS::KEY_SPACE && !jumping)
	{
		speed = 10;
		jumping = true;
		acceleration_y = 4.0;
		force = -40;
		position_x += previous_direction;
	}
	else
	{
		if (key == ASGE::KEYS::KEY_A || previous_key == ASGE::KEYS::KEY_A)
		{
			position_x -= speed;
			previous_direction = -speed;
		}
		else if (key == ASGE::KEYS::KEY_D || previous_key == ASGE::KEYS::KEY_D)
		{
			position_x += speed;
			previous_direction = speed;
		}
		else if (key == -1 && jumping == false)
		{
			position_x += previous_direction;
			previous_direction = 0;
		}
		else
		{
			position_x += previous_direction;
		}
	}
}

void Player::setFloor(int floor_y)
{
	this->floor_y = floor_y;
}

int Player::getFloor()
{
	return floor_y;
}

void Player::update(int previous_key)
{
	previous_position_x = position_x;
	previous_position_y = position_y;
	if (force > 40)
	{
		force = 40;
	}

	position_y += force;
	force += acceleration_y;
	if (position_x >= 0 && position_x <= 1240)
	{
		playerMovement();
	}


	if (position_y > floor_y)
	{
		jumping = false;
		speed = 30;
		force = 0;
		acceleration_y = 0.0;
		position_y = floor_y;
	}

	if (position_x < 0 || position_x > 1240)
	{
		position_x = previous_position_x;
	}
}



double Player::getPreviousPositionX()
{
	return previous_position_x;
}

double Player::getPreviousPositionY()
{
	return previous_position_y;
}

void Player::setAccelerationY(double newAcceleration)
{
	acceleration_y = newAcceleration;
}

void Player::setJumping(bool jumping)
{
	this->jumping = false;
}

