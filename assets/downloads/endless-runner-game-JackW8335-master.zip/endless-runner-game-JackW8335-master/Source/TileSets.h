#pragma once
class TileSets
{
public:
	TileSets();
	~TileSets();
	void makeStairs();
private:
	double position_x;
	double position_y;
};

