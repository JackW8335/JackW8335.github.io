#include <Engine\GameTime.h>
#include <Engine\InputEvents.h>
#include <fstream>
#include "Game.h"
#include "GameFont.h"
#include <iostream>

EndlessGame::~EndlessGame()
{
	this->inputs->unregisterCallback(key_handler_id);

	for (auto& font : GameFont::fonts)
	{
		delete font;
		font = nullptr;
	}
	delete player;
	player = nullptr;
	delete player_sprite;
	player_sprite = nullptr;
	for (int i = 0; i < obstacle_number; i++)
	{
		obstacle_sprite = obstacle[i].getSprite();
		delete obstacle_sprite;
		obstacle_sprite = nullptr;
	}
	delete[] obstacle;
	obstacle = nullptr;

	for (int i = 0; i < number_of_enemies; i++)
	{
		enemy_sprite = enemy[i].getSprite();
		delete enemy_sprite;

		enemy_sprite = nullptr;
	}
	delete[] enemy;
	enemy = nullptr;

	delete background;
	background = nullptr;
}

bool EndlessGame::init()
{
	srand(time(NULL));
	game_action = GameAction::MENU;
	game_width = 1280;
	game_height = 720;


	if (!initAPI(ASGE::Renderer::WindowMode::WINDOWED))
	{
		return false;
	}
	renderer->setWindowTitle("Endless Runner");
	renderer->setClearColour(ASGE::COLOURS::BLACK);
	renderer->setSpriteMode(ASGE::SpriteSortMode::IMMEDIATE);
	toggleFPS();

	this->inputs->use_threads = false;
	this->inputs->addCallbackFnc(
		ASGE::EventType::E_KEY, &EndlessGame::keyHandler, this);
	player = new Player(0, 500);
	obstacle = new Obstacle[20];
	enemy = new Enemy[20];
	player->setFloor(500);
	return true;
}

void EndlessGame::initSprite()
{

	//Create the initial sprites such as the floor, player etc


	floor = renderer->createRawSprite();
	floor->xPos(0);
	floor->yPos(540);
	if (!floor->loadTexture("..\\..\\Resources\\Textures\\Floor.png"))
	{
		floor->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}

	player_sprite = renderer->createRawSprite();
	player_sprite->xPos(player->getPositionX());
	player_sprite->yPos(player->getPositionY());

	if (!player_sprite->loadTexture("..\\..\\Resources\\Textures\\green_square.png"))
	{
		player_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}
	player->setSprite(player_sprite);

	//Spawns enemies and obstacles off screen to enter later.
	generateEnemies();
	generateMap();
}

void EndlessGame::generateMap()
{
	int x = -100;
	int y = 500;
	for (int i = 0; i < obstacle_number; i++)
	{

		obstacle[i].setPosition(x, y);
		obstacle_sprite = obstacle[i].getSprite();
		obstacle_sprite = renderer->createRawSprite();
		obstacle_sprite->xPos(x);
		obstacle_sprite->yPos(y);
		if (!obstacle_sprite->loadTexture("..\\..\\Resources\\Textures\\block.png"))
		{
			obstacle_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
		}
		obstacle[i].setSprite(obstacle_sprite);

	}
}

void EndlessGame::generateEnemies()
{
	//Enemies spawn randomly on the X the Y stays fixed at floor level

	int x;
	int y = 500;
	for (int i = number_of_enemies; i < enemy_cap; i++)
	{
		x = rand() % 500 + 500;
		enemy_sprite = enemy[i].getSprite();
		enemy_sprite = renderer->createRawSprite();
		enemy[i].setPosition(x, y);
		enemy_sprite->xPos(x);
		enemy_sprite->yPos(y);
		number_of_enemies++;

		if (!enemy_sprite->loadTexture("..\\..\\Resources\\Textures\\enemy.png"))
		{
			enemy_sprite->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
		}
		enemy[i].setSprite(enemy_sprite);


	}
}

void EndlessGame::enemyCollision()
{
	//if you overlap with the player box then game ends
	//added damage and health variables
	//Have yet to implement it yet
	for (int i = 0; i < number_of_enemies; i++)
	{
		if (enemy[i].checkCollision(player->getPositionX(), player->getPositionY()))
		{
			game_action = GameAction::GAME_OVER;
		}
	}
}

void EndlessGame::EndlessMap()
{
	int x = 0;
	int y = 0;
	for (int i = 0; i < obstacle_number; i++)
	{
		if (obstacle[i].getPositionX() < -100)
		{
			randomTileSet();
			obstacle_sprite = obstacle[i].getSprite();
		}
		for (int j = 0; j <= obstacle_number; j++)
		{
			while (enemy[i].safeSpawn(enemy[j].getPositionX(), enemy[j].getPositionY()))
			{
				x = rand() % 1000 + 1280;
			}
		}
		if (enemy[i].getPositionX() < -40)
		{
			x = rand() % 1280 + 1280;
			y = 500;

			enemy[i].setPosition(x, y);
			enemy_sprite = enemy[i].getSprite();
			enemy_sprite->xPos(x);
			enemy_sprite->yPos(y);
		}
	}

	//if an obstacle tileset or enemy moves off screen
	//then a new one is spawned 
	//on the right side and moves in from there. 
}


void EndlessGame::randomTileSet()
{
	//Choose randomly whether to create a staircase
	//or a corridor
	int i = 0;
	i = rand() % 2;
	switch (i)
	{
	case 0:
	{
		makeStairs();
		break;
	}
	case 1:
	{
		makeCorridor();
		break;
	}
	}
}

void EndlessGame::makeStairs()
{
	obstacle[0].setPosition(1280, 500);
	obstacle[1].setPosition(1320, 460);
	obstacle[2].setPosition(1360, 420);
	obstacle[3].setPosition(1400, 460);
	obstacle[4].setPosition(1440, 500);

}

void EndlessGame::makeCorridor()
{
	obstacle[0].setPosition(1280, 500);
	obstacle[1].setPosition(1280, 390);
	obstacle[2].setPosition(1680, 290);
	obstacle[3].setPosition(1680, 190);
	obstacle[4].setPosition(1680, 190);
}

void EndlessGame::collisions()
{
	//if you collide with the player
	//set player to the position 
	//before the collision happened
	bool collided = false;
	for (int i = 0; i < obstacle_number; i++)
	{
		if (obstacle[i].checkCollision(player->getPositionX(), player->getPositionY()))
		{
			player->setPositionX(player->getPreviousPositionX());
			player->setPositionY(player->getPreviousPositionY());
			player->setJumping(false);
			break;
		}

	}
}

void EndlessGame::update(const ASGE::GameTime& us)
{
	if (game_action == GameAction::PLAY)
	{
		delta_time += us.delta_time.count() / (1000.0 / 30.0);

		if (delta_time >= 1)
		{
			score++;
			player->update(previous_key);
			levelMovement();
			delta_time--;
			collisions();
			enemyCollision();
			drawSprite();
			EndlessMap();
		}
	}
	if (shouldExit())
	{
		signalExit();
	}
	processGameActions();
}

void EndlessGame::render(const ASGE::GameTime& us)
{
	//print the score
	std::string score_counter = std::to_string(score);
	const char * c = score_counter.c_str();
	renderer->renderText(c, 0, 200, 1.0, ASGE::COLOURS::DARKORANGE);

	if (player->getSprite() != nullptr)
	{
		renderer->renderSprite(*player->getSprite());
	}
	for (int i = 0; i < obstacle_number; i++)
	{
		if (obstacle[i].getSprite() != nullptr)
		{
			renderer->renderSprite(*obstacle[i].getSprite());
		}
	}

	for (int i = 0; i < number_of_enemies; i++)
	{
		if (enemy[i].getSprite() != nullptr)
		{
			renderer->renderSprite(*enemy[i].getSprite());
		}
	}

	if (floor != nullptr)
	{
		renderer->renderSprite(*floor);
	}

	if (background != nullptr)
	{
		renderer->renderSprite(*background);
	}

	if (game_action == GameAction::MENU)
	{
		std::string line;
		std::ifstream myfile("Score.txt");
		if (myfile.is_open())
		{
			while (getline(myfile, line))
			{
				const char * high_score = line.c_str();
				renderer->renderText("High Score :", 400, 50, 3.0, ASGE::COLOURS::LIGHTBLUE);
				renderer->renderText(high_score, 800, 50, 3.0, ASGE::COLOURS::LIGHTBLUE);
			}
			myfile.close();
		}
	}

}


void EndlessGame::keyHandler(const ASGE::SharedEventData data)
{
	previous_key = key;
	const ASGE::KeyEvent* key_event =
		static_cast<const ASGE::KeyEvent*>(data.get());


	key = key_event->key;

	auto action = key_event->action;


	if (action == ASGE::KEYS::KEY_PRESSED)
	{
		if (key == ASGE::KEYS::KEY_ESCAPE)
		{


			game_action = GameAction::EXIT;

		}
	}
	else if (action == ASGE::KEYS::KEY_RELEASED)
	{
		key = -1;
	}
	player->setKey(key);
}

bool EndlessGame::shouldExit() const
{
	return (renderer->exit() || this->exit);
}

void EndlessGame::levelMovement()
{
	for (int i = 0; i < obstacle_number; i++)
	{
		obstacle[i].setPosition(obstacle[i].getPositionX() - 10, obstacle[i].getPositionY());
		enemy[i].setPosition(enemy[i].getPositionX() - 10, enemy[i].getPositionY());

	}
}

void EndlessGame::processGameActions()
{

	if (game_action == GameAction::EXIT)
	{
		this->exit = true;
	}

	if (game_action == GameAction::PLAY)
	{
		delete background;
		background = nullptr;

	}
	if (game_action == GameAction::GAME_OVER)
	{
		gameOver();

	}

	if (game_action == GameAction::MENU)
	{
		gameMenu();

	}
}

void EndlessGame::highScoreTracker()
{
	std::string getFile;
	std::string line;
	std::ifstream myfile("Score.txt");
	if (myfile.is_open())
	{
		while (getline(myfile, line))
		{
			getFile = line;
			fileScore = std::stoi(getFile);

		}
		myfile.close();
	}

	std::ofstream fout;
	fout.open("Score.txt");
	if (fileScore < score)
	{
		fout << score << std::endl;
	}
	else
	{
		fout << fileScore << std::endl;
	}
	fout.close();
}

void EndlessGame::gameOver()
{
	background = renderer->createRawSprite();
	background->xPos(0);
	background->yPos(0);

	if (!background->loadTexture("..\\..\\Resources\\Textures\\gameOver.png"))
	{
		background->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}

	if (key == ASGE::KEYS::KEY_SPACE)
	{
		initSprite();
		restart();
		game_action = GameAction::PLAY;
	}
	highScoreTracker();
}
void EndlessGame::restart()
{
	//resets score
	//player position
	//and obstacles
	score = 0;
	player->setPositionX(40);
	player->setPositionY(500);

	for (int i = 0; i <= obstacle_number; i++)
	{
		obstacle[i].setPosition(-200, 0);
		enemy[i].setPosition(-200, 0);
	}
}
void EndlessGame::gameMenu()
{
	background = renderer->createRawSprite();
	background->xPos(0);
	background->yPos(0);

	if (!background->loadTexture("..\\..\\Resources\\Textures\\Menu.png"))
	{
		background->loadTexture("..\\..\\Resources\\Textures\\no_sprite.png");
	}

	if (key == ASGE::KEYS::KEY_SPACE)
	{
		initSprite();
		game_action = GameAction::PLAY;
	}
}

void EndlessGame::drawSprite()
{

	//Draws all the sprites

	player_sprite = player->getSprite();
	player_sprite->xPos(player->getPositionX());
	player_sprite->yPos(player->getPositionY());

	for (int i = 0; i < obstacle_number; i++)
	{
		obstacle_sprite = obstacle[i].getSprite();
		obstacle_sprite->xPos(obstacle[i].getPositionX());
		obstacle_sprite->yPos(obstacle[i].getPositionY());
	}

	for (int i = 0; i < number_of_enemies; i++)
	{
		enemy_sprite = enemy[i].getSprite();
		enemy_sprite->xPos(enemy[i].getPositionX());
		enemy_sprite->yPos(enemy[i].getPositionY());
	}
}