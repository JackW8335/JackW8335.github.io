#include "Obstacle.h"



Obstacle::Obstacle()
{
	this->position_x = position_x;
	this->position_y = position_y;
	height = 100.0;
	width = 100.0;
}


Obstacle::~Obstacle()
{
}

Obstacle::Obstacle(double position_x, double position_y)
{

}

double Obstacle::getPositionX()
{
	return position_x;
}

double Obstacle::getPositionY()
{
	return position_y;
}

ASGE::Sprite * Obstacle::getSprite()
{
	return obstacle_sprite;
}

int Obstacle::getWidth()
{
	return width;
}

int Obstacle::getHeight()
{
	return height;
}

void Obstacle::setSprite(ASGE::Sprite* obstacle_sprite)
{
	this->obstacle_sprite = obstacle_sprite;
}

bool Obstacle::checkCollision(double position_x, double position_y)
{
	if (position_x < this->position_x + width
		&& position_x > this->position_x - 40.0
		&& position_y > this->position_y - 40.0
		&& position_y < this->position_y + height)
	{
		return true;
	}
	return false;
}

bool Obstacle::safeSpawn(double position_x, double position_y)
{
	if (position_x < this->position_x + width + 10
		&& position_x > this->position_x + width
		&& position_y > this->position_y
		&& position_y < this->position_y + height)
	{
		return true;
	}
	return false;
}

void Obstacle::setPosition(int pos_x, int pos_y)
{
	position_x = pos_x;
	position_y = pos_y;
}
