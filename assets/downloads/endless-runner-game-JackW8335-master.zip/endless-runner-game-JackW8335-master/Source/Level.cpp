#include "Level.h"

void Level::generateRandomLevels(int obstacleNumber, int x, int y )
{
	for (int i = 0; i < obstacleNumber; i++)
	{
		obstacle_sprite = obstacle[i].getSprite();
		obstacle_sprite->xPos(obstacle->getPositionX());
		obstacle_sprite->yPos(obstacle->getPositionY());
	}
}
