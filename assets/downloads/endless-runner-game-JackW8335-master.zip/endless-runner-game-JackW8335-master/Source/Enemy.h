#include <Engine\Sprite.h>
#pragma once
class Enemy
{
public:
	Enemy();
	~Enemy();
	int getPositionX();
	int getPositionY();
	ASGE::Sprite* getSprite();
	void setSprite(ASGE::Sprite* sprite);
	int getDamage();
	bool checkCollision(double position_x, double position_y);
	bool safeSpawn(double position_x, double position_y);
	void setPosition(int pos_x, int pos_y);
private:
	int health = 20;
	int damage = 10;
	int position_x;
	int position_y;
	ASGE::Sprite* sprite = nullptr;
};

