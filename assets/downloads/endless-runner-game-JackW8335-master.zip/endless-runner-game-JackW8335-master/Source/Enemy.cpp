#include "Enemy.h"



Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}

int Enemy::getPositionX()
{
	return position_x;
}

int Enemy::getPositionY()
{
	return position_y;
}

ASGE::Sprite * Enemy::getSprite()
{
	return sprite;
}

void Enemy::setSprite(ASGE::Sprite * sprite)
{
	this->sprite = sprite;
}

int Enemy::getDamage()
{
	return damage;
}

bool Enemy::checkCollision(double position_x, double position_y)
{
	if (position_x <= this->position_x + 40.0
		&& position_x >= this->position_x - 40.0
		&& position_y >= this->position_y - 40.0
		&& position_y <= this->position_y + 40.0)
	{
		return true;
	}
	return false;
}

bool Enemy::safeSpawn(double position_x, double position_y)
{
	if (position_x < this->position_x + 50.0
		&& position_x > this->position_x + 40.0
		&& position_y > this->position_y
		&& position_y < this->position_y + 40.0)
	{
		return true;
	}
	return false;
}

void Enemy::setPosition(int pos_x, int pos_y)
{
	position_x = pos_x;
	position_y = pos_y;
}
