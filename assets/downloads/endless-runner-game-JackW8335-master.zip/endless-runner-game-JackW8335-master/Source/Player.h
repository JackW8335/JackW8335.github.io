#pragma once

#include <Engine/Sprite.h>
#include <Engine\GameTime.h>
#include <Engine\Keys.h>
#include "Obstacle.h"

class Player
{
public:
	Player();
	~Player();
	Player(int, int);
	double getPositionX();
	double getPositionY();
	void setPositionX(double);
	void setPositionY(double);
	void setKey(int key);
	ASGE::Sprite* getSprite();
	void setSprite(ASGE::Sprite* sprite);
	void playerMovement();
	void setFloor(int floor_y);
	int getFloor();
	void update(int previous_key);
	double getPreviousPositionX();
	double getPreviousPositionY();
	void setAccelerationY(double);
	void setJumping(bool jumping);
private:
	int speed;
	int health = 20;
	double previous_position_x;
	double previous_position_y;
	int previous_key;
	double previous_direction;
	double stop_force;
	double force;
	double acceleration_y;
	bool jumping = false;
	double gravity = 1.0;
	int key;
	double position_x;
	double position_y;
	double floor_y;
	ASGE::Sprite* sprite = nullptr;
};

