var searchData=
[
  ['addcallbackfnc',['addCallbackFnc',['../class_a_s_g_e_1_1_input.html#aff53f6d3afd2d4b23d48ce1995d6426b',1,'ASGE::Input::addCallbackFnc(EventType type, T fncPtr, T2 *obj)'],['../class_a_s_g_e_1_1_input.html#afb4027d0c50d3b0943f9894e4a726fc3',1,'ASGE::Input::addCallbackFnc(EventType type, T fncPtr)']]]
];
