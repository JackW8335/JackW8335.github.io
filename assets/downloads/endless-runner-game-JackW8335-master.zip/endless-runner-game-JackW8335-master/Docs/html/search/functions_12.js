var searchData=
[
  ['width',['width',['../class_a_s_g_e_1_1_sprite.html#aa3b56df2e51489ad2f1bfb568a4009d9',1,'ASGE::Sprite::width() const'],['../class_a_s_g_e_1_1_sprite.html#a44f131d5e81efb9b3a5bfcd3f5dc22f9',1,'ASGE::Sprite::width(float width)']]]
];
