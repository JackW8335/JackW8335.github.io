var searchData=
[
  ['scale',['scale',['../class_a_s_g_e_1_1_sprite.html#a1d5f542fb62fdef13334aee49160eda2',1,'ASGE::Sprite::scale() const'],['../class_a_s_g_e_1_1_sprite.html#a2b8b7820089a3656c03bd2eb4acb2e3f',1,'ASGE::Sprite::scale(float scale_value)']]],
  ['sendevent',['sendEvent',['../class_a_s_g_e_1_1_input.html#a46fc5c4cd323869bbbf370e906e7a08c',1,'ASGE::Input']]],
  ['setclearcolour',['setClearColour',['../class_a_s_g_e_1_1_renderer.html#a7297369fcffa9f534bd595ba40dc782d',1,'ASGE::Renderer']]],
  ['setdata',['setData',['../class_a_s_g_e_1_1_texture2_d.html#a6351a2b4979a2c805199c8e017acb9f5',1,'ASGE::Texture2D']]],
  ['setdefaulttextcolour',['setDefaultTextColour',['../class_a_s_g_e_1_1_renderer.html#a39b6f953621eb739cd58f812ced3eebd',1,'ASGE::Renderer']]],
  ['setflipflags',['setFlipFlags',['../class_a_s_g_e_1_1_sprite.html#a939610278f1f9b3992871c15fb54e6cc',1,'ASGE::Sprite']]],
  ['setfont',['setFont',['../class_a_s_g_e_1_1_renderer.html#a3e899c0c89d501243334920bde72d584',1,'ASGE::Renderer']]],
  ['setformat',['setFormat',['../class_a_s_g_e_1_1_texture2_d.html#ac391cfd849c9867da4b9db7a5660fcb5',1,'ASGE::Texture2D']]],
  ['setspritemode',['setSpriteMode',['../class_a_s_g_e_1_1_renderer.html#a3c906e66c7c725d44d39a2612d9d2309',1,'ASGE::Renderer']]],
  ['setwindowedmode',['setWindowedMode',['../class_a_s_g_e_1_1_renderer.html#aac16aa7e07456e03b1f39c6ea24bf950',1,'ASGE::Renderer']]],
  ['setwindowtitle',['setWindowTitle',['../class_a_s_g_e_1_1_renderer.html#ae2f4bff8a3f3eb76b053c47a67eb7e56',1,'ASGE::Renderer']]],
  ['signalexit',['signalExit',['../class_a_s_g_e_1_1_game.html#a499f26119b6005c2073511a3980ec908',1,'ASGE::Game']]],
  ['swapbuffers',['swapBuffers',['../class_a_s_g_e_1_1_renderer.html#acc2ce0b669cab1762667440695d0ee2b',1,'ASGE::Renderer']]]
];
