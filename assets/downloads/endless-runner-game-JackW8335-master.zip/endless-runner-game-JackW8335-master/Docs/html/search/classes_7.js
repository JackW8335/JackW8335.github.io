var searchData=
[
  ['noncopyable',['NonCopyable',['../class_non_copyable.html',1,'']]]
];
