var searchData=
[
  ['colour',['Colour',['../struct_a_s_g_e_1_1_colour.html#a95de77cf43cb491c56e5f5a4e2ee8ca5',1,'ASGE::Colour::Colour()'],['../class_a_s_g_e_1_1_sprite.html#a8dc5f76a4734022f4a7b418ac4e7a4d7',1,'ASGE::Sprite::colour() const'],['../class_a_s_g_e_1_1_sprite.html#a1e4dca35c0d94fccaaf6541913112e3e',1,'ASGE::Sprite::colour(ASGE::Colour sprite_colour)']]],
  ['createrawsprite',['createRawSprite',['../class_a_s_g_e_1_1_renderer.html#aae0b3953b5f8a4dd03e9d00cc85a72fe',1,'ASGE::Renderer']]],
  ['createuniquesprite',['createUniqueSprite',['../class_a_s_g_e_1_1_renderer.html#ab38f3823044a6939b89592abd2b30b21',1,'ASGE::Renderer']]]
];
