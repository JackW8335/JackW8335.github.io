Place your game resources here..
They will be copied to the build directory automatically. 