# Endless Runner 
An endless runner style game based on the dissection of Temple Run in the 1st Year.  

"Endless running" or "infinite running" games are platform games in which the player character is continuously moving forward through a usually procedurally generated, theoretically endless game world. Game controls are limited to making the character jump, attack, or perform special actions.

## Build Instructions
Open the solution in Visual Studio 2017. The game uses the ASGE framework. The projects are prelinked and can be launched either with debugging or without. Resources will be copied to the builds directory, but make sure the working directory in the debugger is set to $(OutDir).

## How to Play
Player one controls with... 



