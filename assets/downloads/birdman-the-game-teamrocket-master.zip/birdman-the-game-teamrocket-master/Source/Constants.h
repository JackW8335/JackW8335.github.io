#pragma once

/*! \file Constants.h
@brief   Constants that are used throughout the game. 
@details Add any new constants to this file. 
*/

constexpr int WINDOW_WIDTH = 1280;  /**< The window width. Defines how wide the game window is. */
constexpr int WINDOW_HEIGHT = 720;  /**< The window height. Defines the height of the game window */
constexpr float BACKGROUND_LAYER = -3.0f;
constexpr float BACKGROUND_OVERLAY = -2.0f;
constexpr float FURNITURE_LAYER = -1.7f;
constexpr float BUTTON_LAYER = -1.5f;
constexpr float FORGROUND_LAYER = -1.0f;
constexpr float UI_LAYER = -0.1f;