#pragma once
#include <Engine/OGLGame.h>

class DeltaTime
{
public:
	float deltaTime(int speed, const ASGE::GameTime&);
private:
};