#include "stdafx.h"
#include "GameOver.h"


GameOver::GameOver()
{
	do_button_once = true;
	world_pos.x = 0;
	world_pos.y = 0;
	title_pos.x = 390;
	title_pos.y = 174;
	button_start.x = 390;
	button_start.y = 350 - 16;
	button_exit.x = 690;
	button_exit.y = 350 - 16;
}

GameOver::~GameOver()
{
}

bool GameOver::init(ASGE::Renderer * renderer)
{
	title = renderer->createUniqueSprite();
	title->xPos(title_pos.x);
	title->yPos(title_pos.y);
	if (!title->loadTexture(".\\Resources\\Textures\\Buttons\\gameover.png"))
	{
		return false;
	}
	start_button_up = renderer->createUniqueSprite();
	start_button_up->xPos(button_start.x);
	start_button_up->yPos(button_start.y);
	if (!start_button_up->loadTexture(".\\Resources\\Textures\\Buttons\\default_button_restart_down.png"))
	{
		return false;
	}
	start_button_down = renderer->createUniqueSprite();
	start_button_down->xPos(button_start.x);
	start_button_down->yPos(button_start.y);
	if (!start_button_down->loadTexture(".\\Resources\\Textures\\Buttons\\default_button_restart.png"))
	{
		return false;
	}
	exit_button_up = renderer->createUniqueSprite();
	exit_button_up->xPos(button_exit.x);
	exit_button_up->yPos(button_exit.y);
	if (!exit_button_up->loadTexture(".\\Resources\\Textures\\Buttons\\default_button_menu_down.png"))
	{
		return false;
	}
	exit_button_down = renderer->createUniqueSprite();
	exit_button_down->xPos(button_exit.x);
	exit_button_down->yPos(button_exit.y);
	if (!exit_button_down->loadTexture(".\\Resources\\Textures\\Buttons\\default_button_menu.png"))
	{
		return false;
	}
	background_floor = renderer->createUniqueSprite();
	if (!background_floor->loadTexture(".\\Resources\\Textures\\Maps\\game_background.png"))
	{
		return false;
	}
	background = renderer->createUniqueSprite();
	if (!background->loadTexture(".\\Resources\\Textures\\Maps\\game_map_walls_menu.png"))
	{
		return false;
	}
	sight = renderer->createUniqueSprite();
	if (!sight->loadTexture(".\\Resources\\Textures\\UI\\blackout_torch.png"))
	{
		return false;
	}

	character = std::make_unique<Player>();
	character->init(renderer);

	loadScore();

	return true;
}


void GameOver::loadScore()
{
	std::ifstream input_file(".\Resources\scores.txt");
	if (input_file.is_open())
	{
		input_file >> level_reached;
		input_file.close();
	}
	level_display = "Level reached: " + std::to_string(level_reached);
}

void GameOver::update(const ASGE::GameTime &dt, const GamePadData & gamepad, ASGE::Renderer * renderer)
{
	moveMap(dt);
	worldPos();
	if (gamepad.is_connected)
	{
		controller(gamepad);
	}
	buttonCollision();
	character->update(dt);
}

void GameOver::worldPos()
{
	background_floor->xPos(world_pos.x - 600);
	background_floor->yPos(world_pos.y - 330);
	title->xPos(title_pos.x + world_pos.x);
	title->yPos(title_pos.y + world_pos.y);
	start_button_up->xPos(button_start.x + world_pos.x);
	start_button_up->yPos(button_start.y + world_pos.y);
	start_button_down->xPos(button_start.x + world_pos.x);
	start_button_down->yPos(button_start.y + world_pos.y);
	exit_button_up->xPos(button_exit.x + world_pos.x);
	exit_button_up->yPos(button_exit.y + world_pos.y);
	exit_button_down->xPos(button_exit.x + world_pos.x);
	exit_button_down->yPos(button_exit.y + world_pos.y);

	if (world_pos.x > area_min_x)
	{
		world_pos.x = area_min_x;
	}
	if (world_pos.x - character->getSprite()->width() < area_max_x)
	{
		world_pos.x = area_max_x + character->getSprite()->width();
	}
	if (world_pos.y > area_min_y)
	{
		world_pos.y = area_min_y;
	}
	if (world_pos.y + character->getSprite()->height() < area_max_y)
	{
		world_pos.y = area_max_y - character->getSprite()->height();
	}
}

void GameOver::moveMap(const ASGE::GameTime & dt)
{
	if (game_action_left == GameActionLeft::LEFT)
	{
		move(deltaTime.deltaTime(speed, dt), 0);
	}
	else if (game_action_right == GameActionRight::RIGHT)
	{

		move(-deltaTime.deltaTime(speed, dt), 0);

	}
	else if (game_action_up == GameActionUp::UP)
	{

		move(0, deltaTime.deltaTime(speed, dt));

	}
	else if (game_action_down == GameActionDown::DOWN)
	{
		move(0, -deltaTime.deltaTime(speed, dt));
	}
}

void GameOver::move(float x, float y)
{
	world_pos.x += x;
	world_pos.y += y;
}

void GameOver::buttonCollision()
{
	if (collision(character->getSprite(), start_button_up.get()))
	{
		start_hovered = true;
		menu_button = MenuButton::START;
	}
	else if (collision(character->getSprite(), exit_button_up.get()))
	{
		exit_hovered = true;
		menu_button = MenuButton::EXIT;
	}
	else
	{
		exit_hovered = false;
		start_hovered = false;
		menu_button = MenuButton::NONE;
	}
}

void GameOver::render(ASGE::Renderer * renderer)
{
	renderer->renderSprite(*background_floor, BACKGROUND_LAYER);
	renderer->renderSprite(*sight, FORGROUND_LAYER);
	renderer->renderSprite(*title, BUTTON_LAYER);
	buttonHover(renderer);
	character->render(renderer, FORGROUND_LAYER);
	renderer->renderText(level_display,world_pos.x,world_pos.y,1.0,ASGE::COLOURS::DARKORANGE);
}

void GameOver::buttonHover(ASGE::Renderer * renderer)
{
	if (start_hovered)
	{
		renderer->renderSprite(*start_button_down, BUTTON_LAYER);
	}
	else
	{
		renderer->renderSprite(*start_button_up, BUTTON_LAYER);
	}

	if (exit_hovered)
	{
		renderer->renderSprite(*exit_button_down, BUTTON_LAYER);
	}
	else
	{
		renderer->renderSprite(*exit_button_up, BUTTON_LAYER);
	}
}

void GameOver::keyHandler(int key, int action)
{
	if (action == ASGE::KEYS::KEY_PRESSED)
	{
		if (key == ASGE::KEYS::KEY_ESCAPE)
		{
			game_state = GameStates::EXIT;
		}
		if (key == ASGE::KEYS::KEY_Z)
		{
			game_state = GameStates::GAME;
		}
		if (key == ASGE::KEYS::KEY_ENTER)
		{
			if (menu_button == MenuButton::START)
			{
				game_state = GameStates::GAME;
			}
			if (menu_button == MenuButton::LEADERBOARD)
			{
				game_state = GameStates::LEADERBOARD;
			}
			if (menu_button == MenuButton::EXIT)
			{
				game_state = GameStates::MENU;
			}
		}
		if (key == ASGE::KEYS::KEY_D)
		{
			game_action_right = GameActionRight::RIGHT;
		}
		if (key == ASGE::KEYS::KEY_A)
		{
			game_action_left = GameActionLeft::LEFT;
		}
		if (key == ASGE::KEYS::KEY_W)
		{
			game_action_up = GameActionUp::UP;
		}
		if (key == ASGE::KEYS::KEY_S)
		{
			game_action_down = GameActionDown::DOWN;
		}
	}
	if (action == ASGE::KEYS::KEY_RELEASED)
	{
		if (key == ASGE::KEYS::KEY_D)
		{
			game_action_right = GameActionRight::NONE;
		}
		if (key == ASGE::KEYS::KEY_A)
		{
			game_action_left = GameActionLeft::NONE;
		}
		if (key == ASGE::KEYS::KEY_W)
		{
			game_action_up = GameActionUp::NONE;
		}
		if (key == ASGE::KEYS::KEY_S)
		{
			game_action_down = GameActionDown::NONE;
		}
	}

}

void GameOver::controller(const GamePadData & gamepad)
{
	if (gamepad.buttons[13] || gamepad.axis[0] <= -0.5)
	{
		game_action_left = GameActionLeft::LEFT;
	}
	else
	{
		game_action_left = GameActionLeft::NONE;
	}

	if (gamepad.buttons[11] || gamepad.axis[0] >= 0.5)
	{
		game_action_right = GameActionRight::RIGHT;
	}
	else
	{
		game_action_right = GameActionRight::NONE;
	}

	if (gamepad.buttons[10] || gamepad.axis[1] >= 0.5)
	{
		game_action_up = GameActionUp::UP;
	}
	else
	{
		game_action_up = GameActionUp::NONE;
	}

	if (gamepad.buttons[12] || gamepad.axis[1] <= -0.5)
	{
		game_action_down = GameActionDown::DOWN;
	}
	else
	{
		game_action_down = GameActionDown::NONE;
	}
	if (gamepad.buttons[0])
	{
		if (do_button_once)
		{
			do_button_once = false;
			if (menu_button == MenuButton::START)
			{
				game_state = GameStates::GAME;
			}
			if (menu_button == MenuButton::LEADERBOARD)
			{
				game_state = GameStates::LEADERBOARD;
			}
			if (menu_button == MenuButton::EXIT)
			{
				game_state = GameStates::MENU;
			}
		}

	}
	else
	{
		do_button_once = true;
	}

}

bool GameOver::collision(ASGE::Sprite* sprite_box, ASGE::Sprite* sprite_box_2)
{
	bool x_true = false;
	bool y_true = false;
	if (sprite_box->xPos() + sprite_box->width() - 2 >= sprite_box_2->xPos() &&
		sprite_box->xPos() <= sprite_box_2->xPos() + sprite_box_2->width())
	{
		x_true = true;
	}
	if (sprite_box->yPos() + sprite_box->height() >= sprite_box_2->yPos() &&
		sprite_box->yPos() <= sprite_box_2->yPos() + sprite_box_2->height())
	{
		y_true = true;
	}

	if (x_true == true && y_true == true)
	{
		return true;
	}
	return false;
}