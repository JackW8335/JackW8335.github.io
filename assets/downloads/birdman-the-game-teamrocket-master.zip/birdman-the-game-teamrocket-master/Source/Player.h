#pragma once
#include "GameObject.h"

class Player : 
	public GameObject
{
public:
	Player() = default;
	~Player() = default;

	// Inherited via GameObject
	virtual bool init(ASGE::Renderer * renderer) override;
	virtual void update(const ASGE::GameTime &) override;
	virtual void render(ASGE::Renderer * renderer, float layer) override;

	ASGE::Sprite* getTopBox();
	ASGE::Sprite* getLeftBox();
	ASGE::Sprite* getRightBox();
	ASGE::Sprite* getBotBox();

	//void reset();

private:
	void collision();
	void move(float x, float y);
	void animation(ASGE::Renderer * renderer);
	void controls(const ASGE::GameTime &);
	void spritePos();

	float speed;
	double timer = 0;

	float player_min_x = 90;
	float player_max_x = 1190;
	float player_min_y = 90;
	float player_max_y = 660;

	bool moving = false;
	bool walking_change_animation = true;
	bool render_xray = false;


	std::unique_ptr<ASGE::Sprite> left_still_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> left_walk1_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> left_walk2_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> right_still_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> right_walk1_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> right_walk2_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> forwards_walk1_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> forwards_walk2_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> back_still_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> back_walk1_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> back_walk2_sprite = nullptr;

	std::unique_ptr<ASGE::Sprite> left_bounding_box = nullptr;
	std::unique_ptr<ASGE::Sprite> right_bounding_box = nullptr;
	std::unique_ptr<ASGE::Sprite> top_bounding_box = nullptr;
	std::unique_ptr<ASGE::Sprite> bot_bounding_box = nullptr;

};