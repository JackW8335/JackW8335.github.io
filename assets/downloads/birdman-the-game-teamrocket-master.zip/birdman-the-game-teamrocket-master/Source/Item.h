#pragma once
#include "GameObject.h"

class Item
{
public:
	Item(int item, int x, int y);
	~Item();
	bool init(ASGE::Renderer * renderer);
	void update();
	void render(ASGE::Renderer * renderer, float layer);

	ASGE::Sprite* getSprite();
	void setPos(float x, float y);
	void setWorldPos(Vector2 _pos);
	void randomSpawn();
	int getItem();
private:
	Vector2 pos;
	Vector2 world_pos;
	int item_selected;

	std::unique_ptr<ASGE::Sprite> notes = nullptr;
	std::unique_ptr<ASGE::Sprite> batteries = nullptr;
	std::unique_ptr<ASGE::Sprite> stopwatch = nullptr;
};