#pragma once
#include "GameObject.h"

class UI :
	public GameObject
{
public:
	UI();
	~UI();
	// Inherited via GameObject
	bool init(ASGE::Renderer * renderer) override;
	void update(const ASGE::GameTime &) override;
	void render(ASGE::Renderer * renderer, float layer) override;

	void setTime(int seconds, int minutes);
	void setScreenSize(float width, float height);
	void setScore(int _score, int _max_score);
	void batteryOn();

	void reset();

	int getScore();
	int getMaxScore();

private:
	void battery(ASGE::Renderer * renderer, float layer);

	float screen_width;
	float screen_height;
	float centre_screen_x;
	float centre_screen_y;
	float ui_width_from_screen_edge = 50;

	int seconds = 00;
	int minutes = 0;
	int score = 0;
	int max_score = 9;
	int battery_life = 0;
	bool no_lights = false;
	double timer;
	double timer_light = 0;
	std::string time;
	std::string note;
	bool xray_on = false;

	std::unique_ptr<ASGE::Sprite> notes = nullptr;
	std::unique_ptr<ASGE::Sprite> energy_bolt = nullptr;
	std::unique_ptr<ASGE::Sprite> battery_full = nullptr;
	std::unique_ptr<ASGE::Sprite> battery_4 = nullptr;
	std::unique_ptr<ASGE::Sprite> battery_3 = nullptr;
	std::unique_ptr<ASGE::Sprite> battery_2 = nullptr;
	std::unique_ptr<ASGE::Sprite> battery_1 = nullptr;
	std::unique_ptr<ASGE::Sprite> battery_empty = nullptr;
	std::unique_ptr<ASGE::Sprite> blackout = nullptr;
	std::unique_ptr<ASGE::Sprite> blackout_mid = nullptr;
	std::unique_ptr<ASGE::Sprite> blackout_large = nullptr;
	std::unique_ptr<ASGE::Sprite> centre = nullptr;
	std::unique_ptr<ASGE::Sprite> lights_out = nullptr;


};