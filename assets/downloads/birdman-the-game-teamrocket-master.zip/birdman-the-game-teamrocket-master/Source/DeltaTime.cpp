#include "DeltaTime.h"

float DeltaTime::deltaTime(int speed, const ASGE::GameTime &dt)
{
	const float pixel_per_sec = speed;
	const float delta_in_sec = dt.delta_time.count() / 1000.0f;
	const float movement_speed = pixel_per_sec * delta_in_sec;
	return movement_speed;
}
