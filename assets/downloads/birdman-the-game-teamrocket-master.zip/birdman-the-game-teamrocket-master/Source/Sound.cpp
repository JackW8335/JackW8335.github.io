#include "stdafx.h"
#include "Sound.h"

AudioEngine::AudioEngine()
{
}

AudioEngine::~AudioEngine()
{
	audio_engine->stopAllSounds();
}

bool AudioEngine::init()
{
	using namespace irrklang;
	audio_engine.reset(createIrrKlangDevice());
	if (!audio_engine)
	{
		// error starting audio engine
		return false;
	}
	audio_engine->setSoundVolume(0.2);
	return true;

}

void AudioEngine::playFootstep(const ASGE::GameTime & dt)
{
	if (timer_step >= 0.3)
	{
		audio_engine->play2D(".\\Resources\\Audio\\footstep.wav", false);
		timer_step -= 0.3;
	}
	else
	{
		timer_step += dt.delta_time.count() / 1000.0f;
	}
}

void AudioEngine::playBackground()
{
	audio_engine->play2D(".\\Resources\\Audio\\Scary Horror Music - Haunted.mp3", true);
}

void AudioEngine::playAlert()
{
	audio_engine->play2D(".\\Resources\\Audio\\alert_2.wav", false);
}

void AudioEngine::playCollect()
{
	audio_engine->play2D(".\\Resources\\Audio\\item collect.mp3", false);
}

void AudioEngine::playJumpScare()
{
	audio_engine->play2D(".\\Resources\\Audio\\Jumpscare.mp3", false);
}

void AudioEngine::stopSound()
{
	audio_engine->stopAllSounds();
}
