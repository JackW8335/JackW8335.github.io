#pragma once
#include "GameObject.h"

class Walls
{
public:
	Walls(int wall_type, float x, float y);
	~Walls();
	bool init(ASGE::Renderer * renderer);
	void update();
	void render(ASGE::Renderer * renderer, float layer);

	ASGE::Sprite* getSprite();

	void setWorldPos(Vector2 _pos);

private:
	Vector2 pos;
	Vector2 world_pos;
	int wall_selected;

	std::unique_ptr<ASGE::Sprite> wall_top = nullptr;
	std::unique_ptr<ASGE::Sprite> wall_mid = nullptr;
	std::unique_ptr<ASGE::Sprite> wall_bot = nullptr;
	std::unique_ptr<ASGE::Sprite> wall_mid_side = nullptr;
	std::unique_ptr<ASGE::Sprite> wall_right = nullptr;
};