#pragma once
#include <string>
#include <atomic>

/** @file Actions.h
@brief   The Actions file define a thread safe game action
@details GameActions are stored here as well as a thread safe
GameAction variable, which has external linkage.
*/


/** @enum GameAction
*   @brief is a strongly typed enum class representing the next game action
*/
enum class GameStates
{
	INVALID = -1,  /**< is a non-valid game action */
	NONE = 0,/**< means no outstanding action to process */
	MENU,
	GAME,
	PAUSE,
	LEADERBOARD,
	GAMEOVER,
	EXIT           /**< signals the intention to exit the game */
};

enum class GameActionLeft
{
	NONE,
	LEFT
};

enum class GameActionRight
{
	NONE,
	RIGHT
};

enum class GameActionUp
{
	NONE,
	UP
};

enum class GameActionDown
{
	NONE,
	DOWN
};

enum class GameActionXRay
{
	NONE,
	XRAY
};

enum class CharacterFacing
{
	NONE,
	DOWN,
	UP,
	LEFT,
	RIGHT
};

enum class MenuButton
{
	NONE,
	START,
	LEADERBOARD,
	EXIT
};

enum class EnemyState
{
	STOP,
	ROAM,
	CHASE
};

enum class Cinematic
{
	NONE,
	PLAY
};


extern std::atomic<GameStates> game_state;
extern std::atomic<GameActionLeft> game_action_left;
extern std::atomic<GameActionRight> game_action_right;
extern std::atomic<GameActionUp> game_action_up;
extern std::atomic<GameActionDown> game_action_down;
extern std::atomic<GameActionXRay> game_action_x_ray;
extern std::atomic<CharacterFacing> character_facing;
extern std::atomic<MenuButton> menu_button;
extern std::atomic<EnemyState> enemy_state;
extern std::atomic<Cinematic> cinematic;