#pragma once
#include <string>

#include <Engine/OGLGame.h>
#include <Engine\Sprite.h>

#include "Vector2.h"
#include "DeltaTime.h"
#include "GameActions.h"

class GameObject
{
public:
	GameObject() = default;
	virtual ~GameObject() = default;

	virtual bool init(ASGE::Renderer* renderer) = 0;
	virtual void update(const ASGE::GameTime &) = 0;
	virtual void render(ASGE::Renderer* renderer, float layer) = 0;

	Vector2 getPos() { return pos; }
	ASGE::Sprite* getSprite() { return sprite.get(); }

protected:
	DeltaTime deltaTime;
	Vector2 pos;
	std::unique_ptr<ASGE::Sprite> sprite = nullptr;

};