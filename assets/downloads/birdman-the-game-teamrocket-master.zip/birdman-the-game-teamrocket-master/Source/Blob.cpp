#include "stdafx.h"
#include "Constants.h"
#include "Blob.h"

namespace
{
	int roaming = 1;
};

Blob::Blob(float x, float y, float _speed, int roam)
{
	pos.x = x;
	pos.y = y;
	speed = _speed;
	roaming = roam;

	large_sprite_pos.x = -400; 
	large_sprite_pos.y = 0;

	roaming_position_1.x = 440 + world_pos.x;
	roaming_position_1.y = 420 + world_pos.y;
	roaming_position_2.x = 440 + world_pos.x;
	roaming_position_2.y = 1020 + world_pos.y;
	roaming_position_3.x = 900 + world_pos.x;
	roaming_position_3.y = 1020 + world_pos.y;
	roaming_position_4.x = 1360 + world_pos.x;
	roaming_position_4.y = 420 + world_pos.y;
	roaming_position_5.x = 2070 + world_pos.x;
	roaming_position_5.y = 420 + world_pos.y;
	roaming_position_6.x = 2070 + world_pos.x;
	roaming_position_6.y = 1020 + world_pos.y;

}

Blob::~Blob()
{
}

bool Blob::init(ASGE::Renderer * renderer)
{
	sprite = renderer->createUniqueSprite();
	if (!sprite->loadTexture(".\\Resources\\Textures\\Enemy\\ene_forwards_animation_1.png"))
	{
		return false;
	}
	animated_sprite = renderer->createUniqueSprite();
	if (!animated_sprite->loadTexture(".\\Resources\\Textures\\Enemy\\ene_forwards_animation_2.png"))
	{
		return false;
	}
	animated_sprite_2 = renderer->createUniqueSprite();
	if (!animated_sprite_2->loadTexture(".\\Resources\\Textures\\Enemy\\ene_forwards_animation_3.png"))
	{
		return false;
	}
	animated_sprite_1L = renderer->createUniqueSprite();
	if (!animated_sprite_1L->loadTexture(".\\Resources\\Textures\\Enemy\\ene_forwards_animation_1_large.png"))
	{
		return false;
	}
	animated_sprite_2L = renderer->createUniqueSprite();
	if (!animated_sprite_2L->loadTexture(".\\Resources\\Textures\\Enemy\\ene_forwards_animation_2_large.png"))
	{
		return false;
	}
	animated_sprite_3L = renderer->createUniqueSprite();
	if (!animated_sprite_3L->loadTexture(".\\Resources\\Textures\\Enemy\\ene_forwards_animation_3_large.png"))
	{
		return false;
	}
	animated_sprite_1L->xPos(large_sprite_pos.y);
	animated_sprite_2L->xPos(large_sprite_pos.y);
	animated_sprite_3L->xPos(large_sprite_pos.y);
	animated_sprite_1L->yPos(large_sprite_pos.x);
	animated_sprite_2L->yPos(large_sprite_pos.x);
	animated_sprite_3L->yPos(large_sprite_pos.x);
	danger_area = renderer->createUniqueSprite();
	if (!danger_area->loadTexture(".\\Resources\\Textures\\Enemy\\danger_area.png"))
	{
		return false;
	}
	alert = renderer->createUniqueSprite();
	if (!alert->loadTexture(".\\Resources\\Textures\\UI\\alert.png"))
	{
		return false;
	}
	return true;
}

void Blob::update(const ASGE::GameTime & dt)
{
	if (is_active)
	{
		if (cinematic == Cinematic::NONE)
		{
			movement(dt);
			sprite->xPos(pos.x + world_pos.x);
			sprite->yPos(pos.y + world_pos.y);
			animated_sprite->xPos(pos.x + world_pos.x);
			animated_sprite->yPos(pos.y + world_pos.y);
			animated_sprite_2->xPos(pos.x + world_pos.x);
			animated_sprite_2->yPos(pos.y + world_pos.y);
			danger_area->xPos((pos.x + world_pos.x) - (danger_area->width() / 2) + 24);
			danger_area->yPos((pos.y + world_pos.y) - (danger_area->height() / 2) + 36);
			alert->xPos((pos.x + world_pos.x) + 20);
			alert->yPos((pos.y + world_pos.y) - (6 + alert->height()));
			updatePos();
		}
		else
		{
			playCinematic(dt);
		}
		if (timer >= 0.25)
		{
			if (animation_change == 1)
			{
				animation_change++;
			}
			else if(animation_change == 2)
			{
				animation_change++;
			}
			else
			{
				animation_change = 1;
			}

			timer -= 0.25;
		}
		else
		{
			timer += dt.delta_time.count() / 1000.0f;
		}
		if (left_right)
		{
			sprite->setFlipFlags(sprite->FLIP_X);
			animated_sprite->setFlipFlags(sprite->FLIP_X);
			animated_sprite_2->setFlipFlags(sprite->FLIP_X);
		}
		else
		{
			sprite->setFlipFlags(sprite->NORMAL);
			animated_sprite->setFlipFlags(sprite->NORMAL);
			animated_sprite_2->setFlipFlags(sprite->NORMAL);
		}
	}
}

void Blob::movement(const ASGE::GameTime & dt)
{
	switch (enemy_state)
	{
		case EnemyState::ROAM:
		{
			roam(dt);
			speed = 50;
			is_alert = false;
			break;
		}
		case EnemyState::CHASE:
		{
			chase(dt, player_pos.x, player_pos.y);
			speed = 100;
			is_alert = true;
			break;
		}
		case EnemyState::STOP:
		{

			break;
		}
	}
}

void Blob::roam(const ASGE::GameTime & dt)
{
	switch (roaming)
	{
		case 1:
		{
			chase(dt, roaming_position_1.x, roaming_position_1.y);
			if ((pos.x + world_pos.x <= roaming_position_1.x + 1) && (pos.x + world_pos.x >= roaming_position_1.x - 1)
				&& (pos.y + world_pos.y <= roaming_position_1.y + 1) && (pos.y + world_pos.y >= roaming_position_1.y - 1))
			{
				roaming++;
			}
			break;
		}
		case 2:
		{
			chase(dt, roaming_position_2.x, roaming_position_2.y);
			if ((pos.x + world_pos.x <= roaming_position_2.x + 1) && (pos.x + world_pos.x >= roaming_position_2.x - 1)
				&& (pos.y + world_pos.y <= roaming_position_2.y + 1) && (pos.y + world_pos.y >= roaming_position_2.y - 1))
			{
				roaming++;
			}
			break;
		}
		case 3:
		{
			chase(dt, roaming_position_3.x, roaming_position_3.y);
			if ((pos.x + world_pos.x <= roaming_position_3.x + 1) && (pos.x + world_pos.x >= roaming_position_3.x - 1)
				&& (pos.y + world_pos.y <= roaming_position_3.y + 1) && (pos.y + world_pos.y >= roaming_position_3.y - 1))
			{
				roaming++;
			}
			break;
		}
		case 4:
		{
			chase(dt, roaming_position_4.x, roaming_position_4.y);
			if ((pos.x + world_pos.x <= roaming_position_4.x + 1) && (pos.x + world_pos.x >= roaming_position_4.x - 1)
				&& (pos.y + world_pos.y <= roaming_position_4.y + 1) && (pos.y + world_pos.y >= roaming_position_4.y - 1))
			{
				roaming++;
			}
			break;
		}
		case 5:
		{
			chase(dt, roaming_position_5.x, roaming_position_5.y);
			if ((pos.x + world_pos.x <= roaming_position_5.x + 1) && (pos.x + world_pos.x >= roaming_position_5.x - 1)
				&& (pos.y + world_pos.y <= roaming_position_5.y + 1) && (pos.y + world_pos.y >= roaming_position_5.y - 1))
			{
				roaming++;
			}
			break;
		}
		case 6:
		{
			chase(dt, roaming_position_6.x, roaming_position_6.y);
			if ((pos.x + world_pos.x <= roaming_position_6.x + 1) && (pos.x + world_pos.x >= roaming_position_6.x - 1)
				&& (pos.y + world_pos.y <= roaming_position_6.y + 1) && (pos.y + world_pos.y >= roaming_position_6.y - 1))
			{
				roaming -= 5;
			}
			break;
		}
	}
}

void Blob::chase(const ASGE::GameTime & dt, float x_pos, float y_pos)
{
	if (pos.x + world_pos.x > x_pos)
	{
		left_right = true;
		move(-deltaTime.deltaTime(speed, dt), 0);
	}
	if (pos.x + world_pos.x < x_pos)
	{
		left_right = false;
		move(deltaTime.deltaTime(speed, dt), 0);
	}
	if (pos.y + world_pos.y > y_pos)
	{
		move(0, -deltaTime.deltaTime(speed, dt));
	}
	if (pos.y + world_pos.y < y_pos)
	{
		move(0, deltaTime.deltaTime(speed, dt));
	}
}

void Blob::render(ASGE::Renderer * renderer, float layer)
{
	if (is_active)
	{
		if (game_action_x_ray == GameActionXRay::XRAY)
		{
			renderer->renderSprite(*danger_area, layer - 0.1);
		}
		if (is_alert)
		{
			renderer->renderSprite(*alert, layer + 0.9);
		}
		if (animation_change == 1)
		{
			renderer->renderSprite(*sprite, layer);
			renderer->renderSprite(*animated_sprite_1L, layer + 1);
		}
		else if (animation_change == 2)
		{
			renderer->renderSprite(*animated_sprite, layer);
			renderer->renderSprite(*animated_sprite_2L, layer + 1);
		}
		else
		{
			renderer->renderSprite(*animated_sprite_2, layer);
			renderer->renderSprite(*animated_sprite_3L, layer + 1);
		}
	}
}

ASGE::Sprite* Blob::getDangerArea()
{
	return danger_area.get();
}

bool Blob::getActive()
{
	return is_active;
}

void Blob::setPlayerPos(Vector2 _pos)
{
	player_pos = _pos;
}

void Blob::setWorldPos(Vector2 _pos)
{
	world_pos = _pos;
}

void Blob::setSpeed(float _speed)
{
	speed = _speed;
}

void Blob::setActive(bool _active)
{
	is_active = _active;
}

void Blob::playCinematic(const ASGE::GameTime & dt)
{
	large_sprite_pos.x += deltaTime.deltaTime(2000, dt);
	large_sprite_pos.y = (WINDOW_HEIGHT / 2) - (animated_sprite_1L->height() / 2);
	animated_sprite_1L->yPos(large_sprite_pos.y);
	animated_sprite_2L->yPos(large_sprite_pos.y);
	animated_sprite_3L->yPos(large_sprite_pos.y);
	animated_sprite_1L->xPos(large_sprite_pos.x);
	animated_sprite_2L->xPos(large_sprite_pos.x);
	animated_sprite_3L->xPos(large_sprite_pos.x);
	if (large_sprite_pos.x >= (WINDOW_WIDTH / 2) - (animated_sprite_1L->width() /2))
	{
		large_sprite_pos.x = (WINDOW_WIDTH / 2) - (animated_sprite_1L->width() / 2);
	}
	if (timer_cinematic >= 5)
	{
		game_state = GameStates::GAMEOVER;
		cinematic = Cinematic::NONE;
	}
	else
	{
		timer_cinematic += dt.delta_time.count() / 1000.0f;
	}
}

void Blob::move(float x, float y)
{
	pos.x += x;
	pos.y += y;
}

void Blob::updatePos()
{
	roaming_position_1.x = 440 + world_pos.x;
	roaming_position_1.y = 420 + world_pos.y;
	roaming_position_2.x = 440 + world_pos.x;
	roaming_position_2.y = 1020 + world_pos.y;
	roaming_position_3.x = 900 + world_pos.x;
	roaming_position_3.y = 1020 + world_pos.y;
	roaming_position_4.x = 1360 + world_pos.x;
	roaming_position_4.y = 420 + world_pos.y;
	roaming_position_5.x = 2070 + world_pos.x;
	roaming_position_5.y = 420 + world_pos.y;
	roaming_position_6.x = 2070 + world_pos.x;
	roaming_position_6.y = 1020 + world_pos.y;
}
