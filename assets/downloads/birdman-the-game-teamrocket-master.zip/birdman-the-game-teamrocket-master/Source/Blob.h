#pragma once
#include "GameObject.h"

class Blob :
	public GameObject
{
public:
	Blob(float x, float y, float _speed, int roam);
	~Blob();

	// Inherited via GameObject
	bool init(ASGE::Renderer * renderer) override;
	void update(const ASGE::GameTime &) override;
	void render(ASGE::Renderer * renderer, float layer) override;

	ASGE::Sprite* getDangerArea();
	bool getActive();

	void setPlayerPos(Vector2 _pos);
	void setWorldPos(Vector2 _pos);
	void setSpeed(float _speed);
	void setActive(bool _active);
	void playCinematic(const ASGE::GameTime & dt);
	

private:
	void updatePos();
	void move(float x, float y);
	void movement(const ASGE::GameTime &);
	void roam(const ASGE::GameTime & dt);
	void chase(const ASGE::GameTime & dt, float x, float y);

	Vector2 player_pos;
	Vector2 world_pos;
	Vector2 large_sprite_pos;
	float speed;
	double timer = 0;
	double timer_cinematic = 0;
	int animation_change = 1;
	bool is_alert = false;
	bool left_right = true;

	bool is_active = false;

	Vector2 roaming_position_1;
	Vector2 roaming_position_2;
	Vector2 roaming_position_3;
	Vector2 roaming_position_4;
	Vector2 roaming_position_5;
	Vector2 roaming_position_6;

	std::unique_ptr<ASGE::Sprite> animated_sprite = nullptr;
	std::unique_ptr<ASGE::Sprite> animated_sprite_2 = nullptr;
	std::unique_ptr<ASGE::Sprite> animated_sprite_1L = nullptr;
	std::unique_ptr<ASGE::Sprite> animated_sprite_2L = nullptr;
	std::unique_ptr<ASGE::Sprite> animated_sprite_3L = nullptr;
	std::unique_ptr<ASGE::Sprite> danger_area = nullptr;
	std::unique_ptr<ASGE::Sprite> alert = nullptr;


};