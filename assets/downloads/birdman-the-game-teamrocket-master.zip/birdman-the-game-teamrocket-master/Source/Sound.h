#pragma once
#include <Engine/OGLGame.h>
#include <irrKlang.h>

class AudioEngine
{
public:
	AudioEngine();
	~AudioEngine();

	bool init();

	void playFootstep(const ASGE::GameTime & dt);
	void playBackground();
	void playAlert();
	void playCollect();
	void playJumpScare();
	void stopSound();

private:
	double timer_step = 0;

	std::unique_ptr<irrklang::ISoundEngine> audio_engine = nullptr;

};