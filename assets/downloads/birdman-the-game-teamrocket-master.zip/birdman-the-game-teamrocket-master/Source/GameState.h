#pragma once
#include <Engine/OGLGame.h>
#include <Engine\GameTime.h>
#include <Engine\InputEvents.h>
#include <Engine\Sprite.h>

#include <fstream>
#include <iostream>
#include <algorithm>
#include <string>

#include "Constants.h"
#include "GameFont.h"
#include "GameActions.h"
#include "Vector2.h"
#include "DeltaTime.h"

class GameState
{
public:
	GameState() = default;
	virtual ~GameState() = default;

	virtual bool init(ASGE::Renderer* renderer) = 0;
	virtual void update(const ASGE::GameTime &, const GamePadData & gamepad, ASGE::Renderer* renderer) = 0;
	virtual void render(ASGE::Renderer* renderer) = 0;
	virtual void keyHandler(int key, int action) = 0;
	virtual void controller(const GamePadData & gamepad) = 0;

protected:
	bool do_button_once;
};