#include "stdafx.h"
#include "UI.h"

UI::UI()
{
}

UI::~UI()
{
}

bool UI::init(ASGE::Renderer * renderer)
{
	centre_screen_x = screen_width / 2;
	centre_screen_y = screen_height / 2;

	notes = renderer->createUniqueSprite();
	if (!notes->loadTexture(".\\Resources\\Textures\\UI\\notes.png"))
	{
		return false;
	}
	notes->xPos(0 + ui_width_from_screen_edge);
	notes->yPos(screen_height - notes->height() - ui_width_from_screen_edge);

	battery_full = renderer->createUniqueSprite();
	if (!battery_full->loadTexture(".\\Resources\\Textures\\UI\\battery_full.png"))
	{
		return false;
	}
	battery_full->xPos(screen_width - battery_full->width() - ui_width_from_screen_edge);
	battery_full->yPos(screen_height - battery_full->height() - ui_width_from_screen_edge);

	energy_bolt = renderer->createUniqueSprite();
	if (!energy_bolt->loadTexture(".\\Resources\\Textures\\UI\\energy.png"))
	{
		return false;
	}
	energy_bolt->xPos(screen_width - battery_full->width() - energy_bolt->width() - ui_width_from_screen_edge - 4);
	energy_bolt->yPos(screen_height - energy_bolt->height() - ui_width_from_screen_edge);

	battery_4 = renderer->createUniqueSprite();
	if (!battery_4->loadTexture(".\\Resources\\Textures\\UI\\battery_4.png"))
	{
		return false;
	}
	battery_4->xPos(screen_width - battery_full->width() - ui_width_from_screen_edge);
	battery_4->yPos(screen_height - battery_full->height() - ui_width_from_screen_edge);

	battery_3 = renderer->createUniqueSprite();
	if (!battery_3->loadTexture(".\\Resources\\Textures\\UI\\battery_3.png"))
	{
		return false;
	}
	battery_3->xPos(screen_width - battery_full->width() - ui_width_from_screen_edge);
	battery_3->yPos(screen_height - battery_full->height() - ui_width_from_screen_edge);

	battery_2 = renderer->createUniqueSprite();
	if (!battery_2->loadTexture(".\\Resources\\Textures\\UI\\battery_2.png"))
	{
		return false;
	}
	battery_2->xPos(screen_width - battery_full->width() - ui_width_from_screen_edge);
	battery_2->yPos(screen_height - battery_full->height() - ui_width_from_screen_edge);

	battery_1 = renderer->createUniqueSprite();
	if (!battery_1->loadTexture(".\\Resources\\Textures\\UI\\battery_1.png"))
	{
		return false;
	}
	battery_1->xPos(screen_width - battery_full->width() - ui_width_from_screen_edge);
	battery_1->yPos(screen_height - battery_full->height() - ui_width_from_screen_edge);

	battery_empty = renderer->createUniqueSprite();
	if (!battery_empty->loadTexture(".\\Resources\\Textures\\UI\\battery_empty.png"))
	{
		return false;
	}
	battery_empty->xPos(screen_width - battery_full->width() - ui_width_from_screen_edge);
	battery_empty->yPos(screen_height - battery_full->height() - ui_width_from_screen_edge);

	blackout = renderer->createUniqueSprite();
	if (!blackout->loadTexture(".\\Resources\\Textures\\UI\\blackout.png"))
	{
		return false;
	}
	blackout_mid = renderer->createUniqueSprite();
	if (!blackout_mid->loadTexture(".\\Resources\\Textures\\UI\\blackout_torch.png"))
	{
		return false;
	}
	blackout_large = renderer->createUniqueSprite();
	if (!blackout_large->loadTexture(".\\Resources\\Textures\\UI\\blackout_torch_large.png"))
	{
		return false;
	}

	centre = renderer->createUniqueSprite();
	if (!centre->loadTexture(".\\Resources\\Textures\\UI\\centre.png"))
	{
		return false;
	}
	lights_out = renderer->createUniqueSprite();
	if (!lights_out->loadTexture(".\\Resources\\Textures\\UI\\lights_out.png"))
	{
		return false;
	}
	return true;
}

void UI::update(const ASGE::GameTime &dt)
{
	note = std::to_string(score) + "/" + std::to_string(max_score);
	if (seconds < 10)
	{
		time = std::to_string(minutes) + ":0" + std::to_string(seconds);
	}
	else
	{
		time = std::to_string(minutes) + ":" + std::to_string(seconds);
	}
	if (game_action_x_ray == GameActionXRay::XRAY)
	{
		xray_on = true;
	}
	else
	{
		xray_on = false;
	}

	if (battery_life > 0)
	{
		if (timer >= 1)
		{
			battery_life--;
			timer -= 1;
		}
		else
		{
			timer += dt.delta_time.count() / 1000.0f;
		}
		energy_bolt->colour(ASGE::COLOURS::WHITE);
	}
	else
	{
		if (timer_light >= 2)
		{
			if (no_lights)
			{
				no_lights = false;
				timer_light -= ((rand() % 19) / 10);
			}
			else
			{
				no_lights = true;
				timer_light -= 0.1;
			}
		}
		else
		{
			timer_light += dt.delta_time.count() / 1000.0f;
		}
		energy_bolt->colour(ASGE::COLOURS::DARKGRAY);
	}
}

void UI::render(ASGE::Renderer * renderer, float layer)
{
	if (!xray_on)
	{
		battery(renderer, layer);
	}
	else
	{
		renderer->renderSprite(*centre, layer);
	}
	renderer->renderSprite(*energy_bolt, layer);
	renderer->renderSprite(*notes, layer - 0.1);
	renderer->renderText(time, centre_screen_x - 30, 30, ASGE::COLOURS::WHITE);
	renderer->renderText(note, notes->xPos(), notes->yPos() + 10, ASGE::COLOURS::WHITE);
}

void UI::setTime(int _seconds, int _minutes)
{
	seconds = _seconds;
	minutes = _minutes;
}

void UI::setScreenSize(float width, float height)
{
	screen_width = width;
	screen_height = height;
}

void UI::setScore(int _score, int _max_score)
{
	score = _score;
	max_score = _max_score;
}

void UI::batteryOn()
{
	battery_life = 25;
}

void UI::reset()
{
	int score = 0;
	int battery_life = 0;
}

int UI::getScore()
{
	return score;
}

int UI::getMaxScore()
{
	return max_score;
}

void UI::battery(ASGE::Renderer * renderer, float layer)
{
	if (battery_life == 0)
	{
		renderer->renderSprite(*blackout, layer - 0.2);
		renderer->renderSprite(*battery_empty, layer);
		if (no_lights)
		{
			renderer->renderSprite(*lights_out, layer - 0.2);
		}
	}
	else if(battery_life > 0 && battery_life < 5)
	{
		renderer->renderSprite(*blackout_mid, layer - 0.2);
		renderer->renderSprite(*battery_1, layer);

	}
	else if (battery_life > 4 && battery_life < 10)
	{
		renderer->renderSprite(*blackout_mid, layer - 0.2);
		renderer->renderSprite(*battery_2, layer);
		
	}
	else if (battery_life > 9 && battery_life < 15)
	{
		renderer->renderSprite(*blackout_mid, layer - 0.2);
		renderer->renderSprite(*battery_3, layer);
		
	}
	else if (battery_life > 14 && battery_life < 20)
	{
		renderer->renderSprite(*blackout_large, layer - 0.2);
		renderer->renderSprite(*battery_4, layer);
		
	}
	else if (battery_life > 19 && battery_life < 26)
	{
		renderer->renderSprite(*blackout_large, layer - 0.2);
		renderer->renderSprite(*battery_full, layer);
		
	}

}
