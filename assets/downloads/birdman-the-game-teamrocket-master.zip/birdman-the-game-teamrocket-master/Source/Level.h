#pragma once
#include <Engine/OGLGame.h>
#include <Engine\GameTime.h>
#include <Engine\Sprite.h>

#include <fstream>
#include <iostream>
#include <algorithm>
#include <string>

#include "Constants.h"
#include "GameFont.h"
#include "GameActions.h"
#include "Vector2.h"
#include "DeltaTime.h"
#include "Walls.h"
#include "Furniture.h"
#include "Blob.h"
#include "Item.h"
#include "Player.h"
#include "UI.h"
#include "Sound.h"

class Level
{
public:
	Level() = default;
	virtual ~Level() = default;

	virtual bool init(ASGE::Renderer* renderer) = 0;
	virtual void update(const ASGE::GameTime &, Player* character, UI* ui, AudioEngine* audio) = 0;
	virtual void render(ASGE::Renderer* renderer) = 0;
	void setWorldPos(Vector2 _pos) { world_pos = _pos; };
	bool getLeftMovement() { return left_movement; };
	bool getRightMovement() { return right_movement; };
	bool getUpMovement() { return up_movement; };
	bool getDownMovement() { return down_movement; };
	int getLevel() { return current_level; };

protected:
	int current_level;
	Vector2 world_pos;
	bool left_movement = true;
	bool right_movement = true;
	bool up_movement = true;
	bool down_movement = true;

};