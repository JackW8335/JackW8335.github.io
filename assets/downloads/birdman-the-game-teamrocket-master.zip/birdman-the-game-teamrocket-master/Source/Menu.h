#pragma once
#include "GameState.h"
#include "Player.h"
#include "Sound.h"

class Menu :
	public GameState
{
public:
	Menu();
	~Menu();

	// Inherited via GameState
	virtual bool init(ASGE::Renderer * renderer) override;
	virtual void update(const ASGE::GameTime &, const GamePadData & gamepad, ASGE::Renderer * renderer) override;
	virtual void render(ASGE::Renderer * renderer) override;
	virtual void keyHandler(int key, int action) override;

private:
	DeltaTime deltaTime;


	void worldPos();
	void moveMap(const ASGE::GameTime & dt);
	void move(float x, float y);
	void buttonCollision();
	void buttonHover(ASGE::Renderer * renderer);
	virtual void controller(const GamePadData & gamepad) override;
	bool collision(ASGE::Sprite* sprite_box, ASGE::Sprite* sprite_box_2);

	bool start_hovered = false;
	bool exit_hovered = false;
	float speed = 300;
	Vector2 world_pos;
	float area_min_x = 410;
	float area_max_x = -410;
	float area_min_y = 100;
	float area_max_y = -200;
	Vector2 title_pos;
	Vector2 button_start;
	Vector2 button_exit;


	std::unique_ptr<ASGE::Sprite> title = nullptr;
	std::unique_ptr<ASGE::Sprite> start_button_up = nullptr;
	std::unique_ptr<ASGE::Sprite> start_button_down = nullptr;
	std::unique_ptr<ASGE::Sprite> exit_button_up = nullptr;
	std::unique_ptr<ASGE::Sprite> exit_button_down = nullptr;
	std::unique_ptr<ASGE::Sprite> sight = nullptr;
	std::unique_ptr<ASGE::Sprite> background = nullptr;
	std::unique_ptr<ASGE::Sprite> background_floor = nullptr;

	std::unique_ptr<Player> character = nullptr;
	std::unique_ptr<AudioEngine> audio = nullptr;



};
