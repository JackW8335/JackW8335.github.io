#include "stdafx.h"
#include "Level1.h"

Level1::Level1()
{
	current_level = 1;
	door_pos.x = 1200;
	door_pos.y = 140;
	vec_blobs.reserve(5);
}

Level1::~Level1()
{
	vec_wall.clear();
	vec_furniture.clear();
	vec_item.clear();
	vec_blobs.clear();
}

bool Level1::init(ASGE::Renderer * renderer)
{
	game_background = renderer->createUniqueSprite();
	if (!game_background->loadTexture(".\\Resources\\Textures\\Maps\\game_background_carpet.png"))
	{
		return false;
	}
	game_walls = renderer->createUniqueSprite();
	if (!game_walls->loadTexture(".\\Resources\\Textures\\Maps\\game_map_walls.png"))
	{
		return false;
	}
	game_walls_inside = renderer->createUniqueSprite();
	if (!game_walls_inside->loadTexture(".\\Resources\\Textures\\Maps\\game_map_layout.png"))
	{
		return false;
	}
	door = renderer->createUniqueSprite();
	if (!door->loadTexture(".\\Resources\\Textures\\Maps\\door.png"))
	{
		return false;
	}
	door_open_sprite = renderer->createUniqueSprite();
	if (!door_open_sprite->loadTexture(".\\Resources\\Textures\\Maps\\door_open.png"))
	{
		return false;
	}

	levelInit(renderer);
	return true;
}

void Level1::levelInit(ASGE::Renderer * renderer)
{
	vec_wall.emplace_back(new Walls(1, 760, 240));
	vec_wall.emplace_back(new Walls(1, 1620, 240));
	vec_wall.emplace_back(new Walls(2, 760, 500));
	vec_wall.emplace_back(new Walls(2, 1620, 500));
	vec_wall.emplace_back(new Walls(3, 760, 1100));
	vec_wall.emplace_back(new Walls(3, 1620, 1100));
	vec_wall.emplace_back(new Walls(4, 1660, 680));
	vec_wall.emplace_back(new Walls(5, 2140, 680));
	for (auto& wall : vec_wall)
	{
		wall->init(renderer);
	}
	vec_furniture.emplace_back(new Furniture(1, 200, 290));
	vec_furniture.emplace_back(new Furniture(1, 1470, 290));
	vec_furniture.emplace_back(new Furniture(2, 820, 290));
	vec_furniture.emplace_back(new Furniture(6, 400, 290));
	vec_furniture.emplace_back(new Furniture(3, 1800, 290));
	vec_furniture.emplace_back(new Furniture(5, 1970, 290));
	vec_furniture.emplace_back(new Furniture(4, 1700, 880));
	vec_furniture.emplace_back(new Furniture(5, 2200, 880));
	for (auto& furniture : vec_furniture)
	{
		furniture->init(renderer);
	}
	vec_item.emplace_back(new Item(3, 300, 300));
	//vec_item.emplace_back(new Item(2, 1000, 500));
	vec_item.emplace_back(new Item(1, 2200, 1250));
	for (auto& item : vec_item)
	{
		item->init(renderer);
	}
	vec_blobs.emplace_back(new Blob(2500, 420, 100, 1));
	vec_blobs.emplace_back(new Blob(2500, 420, 100, 3));
	vec_blobs.emplace_back(new Blob(2500, 420, 100, 4));
	vec_blobs.emplace_back(new Blob(2500, 420, 100, 2));
	vec_blobs.emplace_back(new Blob(2500, 420, 100, 5));
	for (auto& blob : vec_blobs)
	{
		blob->init(renderer);
	}
}

void Level1::update(const ASGE::GameTime &dt, Player* character, UI* ui, AudioEngine* audio)
{
	if (cinematic == Cinematic::NONE)
	{
		worldPosUpdate();
		if (ui->getScore() == 3)
		{
			if (do_once)
			{
				addBlob();
				do_once = false;
			}
		}
		if (ui->getScore() == ui->getMaxScore())
		{
			for (auto& item : vec_item)
			{
				if (item->getItem() == 1)
				{
					item->setPos(-1000, -1000);
				}
			}
			door_open = true;
			if (collision(character->getSprite(), door.get()))
			{
				current_level = 2;
			}
		}
		for (auto& walls : vec_wall)
		{
			walls->setWorldPos(world_pos);
			walls->update();
		}
		for (auto& furniture : vec_furniture)
		{
			furniture->setWorldPos(world_pos);
			furniture->update();
		}
		for (auto& item : vec_item)
		{
			item->setWorldPos(world_pos);
			item->update();
		}
		for (auto& blob : vec_blobs)
		{
			blob->setPlayerPos(character->getPos());
			blob->setWorldPos(world_pos);
			blob->update(dt);
		}
		wallCollision(character);
		itemCollision(character, ui, audio);
		furnitureCollision(character);
		mobCollision(character, audio);
		ui->setScore(notes, max_notes);
	}
	else
	{
		for (auto& blob : vec_blobs)
		{
			blob->update(dt);
		}
	}
	
}

void Level1::worldPosUpdate()
{
	game_background->xPos(world_pos.x);
	game_background->yPos(world_pos.y);
	game_walls->xPos(world_pos.x);
	game_walls->yPos(world_pos.y);
	game_walls_inside->xPos(world_pos.x);
	game_walls_inside->yPos(world_pos.y);
	door->xPos(door_pos.x + world_pos.x);
	door->yPos(door_pos.y + world_pos.y);
	door_open_sprite->xPos(door_pos.x + world_pos.x);
	door_open_sprite->yPos(door_pos.y + world_pos.y);
}

void Level1::wallCollision(Player* character)
{
	for (auto& wall : vec_wall)
	{
		if (collision(wall->getSprite(), character->getTopBox()))
		{
			game_action_up = GameActionUp::NONE;
			up_movement = false;
		}
		else
		{
			up_movement = true;
		}
		if (collision(wall->getSprite(), character->getLeftBox()))
		{
			game_action_left = GameActionLeft::NONE;
			left_movement = false;
		}
		else
		{
			left_movement = true;
		}
		if (collision(wall->getSprite(), character->getRightBox()))
		{
			game_action_right = GameActionRight::NONE;
			right_movement = false;
		}
		else
		{
			right_movement = true;
		}
		if (collision(wall->getSprite(), character->getBotBox()))
		{
			game_action_down = GameActionDown::NONE;
			down_movement = false;
		}
		else
		{
			down_movement = true;
		}
		for (auto& item : vec_item)
		{
			if (collision(wall->getSprite(), item->getSprite()))
			{
				item->randomSpawn();
			}
		}
	}
}

void Level1::itemCollision(Player* character, UI* ui, AudioEngine* audio)
{
	for (auto& item : vec_item)
	{
		if (collision(item->getSprite(), character->getSprite()))
		{

			if (item->getItem() == 1)
			{
				notes++;
				audio->playCollect();
			}
			else if (item->getItem() == 2)
			{
				enemy_state = EnemyState::STOP;
			}
			else if (item->getItem() == 3)
			{
				ui->batteryOn();
			}

			item->randomSpawn();
		}
	}
}

void Level1::furnitureCollision(Player* character)
{
	for (auto& furniture : vec_furniture)
	{
		if (collision(furniture->getSprite(), character->getTopBox()))
		{
			game_action_up = GameActionUp::NONE;
			up_movement = false;
		}
		else
		{
			up_movement = true;
		}
		if (collision(furniture->getSprite(), character->getLeftBox()))
		{
			game_action_left = GameActionLeft::NONE;
			left_movement = false;
		}
		else
		{
			left_movement = true;
		}
		if (collision(furniture->getSprite(), character->getRightBox()))
		{
			game_action_right = GameActionRight::NONE;
			right_movement = false;
		}
		else
		{
			right_movement = true;
		}
		if (collision(furniture->getSprite(), character->getBotBox()))
		{
			game_action_down = GameActionDown::NONE;
			down_movement = false;
		}
		else
		{
			down_movement = true;
		}
		for (auto& item : vec_item)
		{
			if (collision(furniture->getSprite(), item->getSprite()))
			{
				item->randomSpawn();
			}
		}
	}
}

void Level1::mobCollision(Player* character, AudioEngine* audio)
{
	for (auto& blob : vec_blobs)
	{
		if (blob->getActive())
		{
			if (collision(blob->getSprite(), character->getSprite()))
			{
				audio->stopSound();
				audio->playJumpScare();
				cinematic = Cinematic::PLAY;
			}
			if (collision(blob->getDangerArea(), character->getSprite()))
			{
				enemy_state = EnemyState::CHASE;
				if (play_alert_once)
				{
					audio->playAlert();
					play_alert_once = false;
				}
				break;
			}
			else
			{
				play_alert_once = true;
				enemy_state = EnemyState::ROAM;
			}
		}
	}
}

void Level1::addBlob()
{
	if (vec_blobs.size() == 5)
	{
		for (auto& blob : vec_blobs)
		{
			if (blob->getActive() == false)
			{
				blob->setActive(true);
				break;
			}
		}
	}
}

void Level1::render(ASGE::Renderer * renderer)
{
	renderer->renderSprite(*game_background, BACKGROUND_LAYER);
	renderer->renderSprite(*game_walls_inside, BACKGROUND_OVERLAY);
	if (door_open)
	{
		renderer->renderSprite(*door_open_sprite, BACKGROUND_OVERLAY);
	}
	else
	{
		renderer->renderSprite(*door, BACKGROUND_OVERLAY);
	}
	/*for (auto& wall : vec_wall)
	{
		wall->render(renderer, FORGROUND_LAYER + 0.6);
	}*/
	for (auto& furniture : vec_furniture)
	{
		furniture->render(renderer, FURNITURE_LAYER);
	}
	for (auto& item : vec_item)
	{
		item->render(renderer, BACKGROUND_OVERLAY);
	}
	for (auto& blob : vec_blobs)
	{
		blob->render(renderer, FORGROUND_LAYER);
	}
}

bool Level1::collision(ASGE::Sprite* sprite_box, ASGE::Sprite* sprite_box_2)
{
	bool x_true = false;
	bool y_true = false;
	if (sprite_box->xPos() + sprite_box->width() - 2 >= sprite_box_2->xPos() &&
		sprite_box->xPos() <= sprite_box_2->xPos() + sprite_box_2->width())
	{
		x_true = true;
	}
	if (sprite_box->yPos() + sprite_box->height() >= sprite_box_2->yPos() &&
		sprite_box->yPos() <= sprite_box_2->yPos() + sprite_box_2->height())
	{
		y_true = true;
	}

	if (x_true == true && y_true == true)
	{
		return true;
	}
	return false;
}