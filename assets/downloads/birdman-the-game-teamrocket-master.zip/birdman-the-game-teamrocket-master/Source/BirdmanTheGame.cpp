#include <Engine\InputEvents.h>

#include "BirdmanTheGame.h"
#include "GameFont.h"

#include "Vector2.h"
#include "GameActions.h"
#include "Constants.h"


namespace {
	const float BACKGROUND_LAYER = -1.0f;
	const float FOREGROUND_LAYER = 0.0f;
};

BirdmanTheGame::~BirdmanTheGame()
{
	this->inputs->unregisterCallback(key_handler_id);
	LoadedGameFont::loaded_fonts.clear();
}

bool BirdmanTheGame::init()
{
	game_width = WINDOW_WIDTH;
	game_height = WINDOW_HEIGHT;

	if (!initAPI(ASGE::Renderer::WindowMode::WINDOWED))
	{
		return false;
	}

	renderer->setWindowTitle("Birdman");
	renderer->setClearColour(ASGE::COLOURS::BLACK);
	renderer->setSpriteMode(ASGE::SpriteSortMode::FRONT_TO_BACK);
	//toggleFPS();

	this->inputs->use_threads = false;

	LoadedGameFont::loaded_fonts.push_back(LoadedGameFont(renderer->loadFont(".\\Resources\\Fonts\\Minecraft.ttf", 32), "Main", 32));
	if (LoadedGameFont::loaded_fonts[0].id == -1)
	{
		return false;
	}
	LoadedGameFont::loaded_fonts.push_back(LoadedGameFont(renderer->loadFont(".\\Resources\\Fonts\\MonoFont.ttf", 32), "Smooth", 32));
	if (LoadedGameFont::loaded_fonts[1].id == -1)
	{
		return false;
	}
	renderer->setFont(2);

	key_handler_id = this->inputs->addCallbackFnc(
		ASGE::EventType::E_KEY, &BirdmanTheGame::keyHandler, this);

	LoadedGameFont::loaded_fonts.reserve(5);

	
	return true;
}

void BirdmanTheGame::update(const ASGE::GameTime& ms)
{
	auto& gamepad = inputs->getGamePad(0);

	switch (game_state)
	{
		case GameStates::MENU:
		{
			scene.reset();
			scene = std::unique_ptr<Menu>(new Menu);
			scene->init(renderer.get());
			game_state = GameStates::NONE;
			break;
		}
		case GameStates::GAME:
		{
			scene.reset();
			scene = std::unique_ptr<InGame>(new InGame);
			scene->init(renderer.get());
			game_state = GameStates::NONE;
			break;
		}
		case GameStates::GAMEOVER:
		{
			scene.reset();
			scene = std::unique_ptr<GameOver>(new GameOver);
			scene->init(renderer.get());
			game_state = GameStates::NONE;

			break;
		}
		case GameStates::EXIT:
		{
			signalExit();
			break;
		}
	}
	scene->update(ms, gamepad, renderer.get());
}

void BirdmanTheGame::render(const ASGE::GameTime& ms)
{
	scene->render(renderer.get());
}

void BirdmanTheGame::keyHandler(const ASGE::SharedEventData data)
{
	const ASGE::KeyEvent* key_event =
		static_cast<const ASGE::KeyEvent*>(data.get());

	auto key = key_event->key;
	auto action = key_event->action;

	scene->keyHandler(key, action);

	
}
