#include "stdafx.h"
#include "Game.h"
#include "Level1.h"
#include "Level2.h"

InGame::InGame()
{
	world_pos.x = 0;
	world_pos.y = 0;
}

InGame::~InGame()
{

}

bool InGame::init(ASGE::Renderer * renderer)
{
	pause_background = renderer->createUniqueSprite();
	pause_background->xPos(540);
	pause_background->yPos(260);
	if (!pause_background->loadTexture(".\\Resources\\Textures\\Pause.png"))
	{
		return false;
	}

	current_level = std::unique_ptr<Level1>(new Level1);
	current_level->init(renderer);

	character = std::make_unique<Player>();
	character->init(renderer);

	ui = std::make_unique<UI>();
	ui->setScreenSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	ui->init(renderer);

	audio = std::make_unique<AudioEngine>();
	audio->init();
	audio->playBackground();

	return true;
}

void InGame::update(const ASGE::GameTime & dt, const GamePadData & gamepad, ASGE::Renderer * renderer)
{
	if (cinematic == Cinematic::NONE)
	{
		if (gamepad.is_connected)
		{
			controller(gamepad);
		}
		if (!pause)
		{
			ui->setTime(seconds, minutes);
			ui->update(dt);
			if (current_level->getLevel() == 2)
			{
				if (load_level_2)
				{
					current_level.reset();
					current_level = std::unique_ptr<Level2>(new Level2);
					current_level->init(renderer);
					ui->setScore(notes, 9);
					seconds = 59;
					minutes = 2;
					load_level_2 = false;
				}
			}
			worldPos();
			current_level->update(dt, character.get(), ui.get(), audio.get());
			current_level->setWorldPos(world_pos);
			character->update(dt);
			moveMap(dt);
			saveScore();
			timer(dt);
		}
	}
	else
	{
		current_level->update(dt, character.get(), ui.get(), audio.get());
	}
}

void InGame::worldPos()
{
	if (world_pos.x > area_min_x)
	{
		world_pos.x = area_min_x;
	}
	if (world_pos.x - character->getSprite()->width() < area_max_x)
	{
		world_pos.x = area_max_x + character->getSprite()->width();
	}
	if (world_pos.y > area_min_y)
	{
		world_pos.y = area_min_y;
	}
	if (world_pos.y + character->getSprite()->height() < area_max_y)
	{
		world_pos.y = area_max_y - character->getSprite()->height();
	}
}

void InGame::moveMap(const ASGE::GameTime & dt)
{
	if (game_action_left == GameActionLeft::LEFT)
	{
		if (current_level->getLeftMovement())
		{
			move(deltaTime.deltaTime(speed, dt), 0);
			audio->playFootstep(dt);
		}
	}
	else if (game_action_right == GameActionRight::RIGHT)
	{
		if (current_level->getRightMovement())
		{
			move(-deltaTime.deltaTime(speed, dt), 0);
			audio->playFootstep(dt);
		}
	}
	else if (game_action_up == GameActionUp::UP)
	{
		if (current_level->getUpMovement())
		{
			move(0, deltaTime.deltaTime(speed, dt));
			audio->playFootstep(dt);
		}
	}
	else if (game_action_down == GameActionDown::DOWN)
	{
		if (current_level->getDownMovement())
		{
			move(0, -deltaTime.deltaTime(speed, dt));
			audio->playFootstep(dt);
		}
	}
}

void InGame::move(float x, float y)
{
	world_pos.x += x;
	world_pos.y += y;
}

void InGame::timer(const ASGE::GameTime & dt)
{
	if (timer_second >= 1)
	{
		if (minutes == 0 && seconds == 0)
		{
			enemy_state = EnemyState::CHASE;
		}
		else
		{
			seconds--;
			if (seconds < 0)
			{
				minutes--;
				seconds = 59;
			}
			timer_second -= 1;
		}
	}
	else
	{
		timer_second += dt.delta_time.count() / 1000.0f;
	}
}

void InGame::render(ASGE::Renderer * renderer)
{
	current_level->render(renderer);
	ui->render(renderer, UI_LAYER);
	character->render(renderer, -1.5);
	if (pause)
	{
		renderer->renderSprite(*pause_background, UI_LAYER);
	}
}

void InGame::keyHandler(int key, int action)
{
	if (pause)
	{
		if (action == ASGE::KEYS::KEY_PRESSED)
		{
			if (key == ASGE::KEYS::KEY_ESCAPE)
			{
				pause = false;
			}
		}
	}
	else
	{
		if (action == ASGE::KEYS::KEY_PRESSED)
		{
			if (key == ASGE::KEYS::KEY_ESCAPE)
			{
				pause = true;
			}
			if (key == ASGE::KEYS::KEY_D)
			{
				game_action_right = GameActionRight::RIGHT;
			}
			if (key == ASGE::KEYS::KEY_A)
			{
				game_action_left = GameActionLeft::LEFT;
			}
			if (key == ASGE::KEYS::KEY_W)
			{
				game_action_up = GameActionUp::UP;
			}
			if (key == ASGE::KEYS::KEY_S)
			{
				game_action_down = GameActionDown::DOWN;
			}
			if (key == ASGE::KEYS::KEY_X)
			{
				if (x_ray)
				{
					game_action_x_ray = GameActionXRay::XRAY;
					x_ray = false;
				}
				else
				{
					game_action_x_ray = GameActionXRay::NONE;
					x_ray = true;
				}
			}
		}
		if (action == ASGE::KEYS::KEY_RELEASED)
		{
			if (key == ASGE::KEYS::KEY_D)
			{
				game_action_right = GameActionRight::NONE;
			}
			if (key == ASGE::KEYS::KEY_A)
			{
				game_action_left = GameActionLeft::NONE;
			}
			if (key == ASGE::KEYS::KEY_W)
			{
				game_action_up = GameActionUp::NONE;
			}
			if (key == ASGE::KEYS::KEY_S)
			{
				game_action_down = GameActionDown::NONE;
			}
		}
	}
}

void InGame::controller(const GamePadData & gamepad)
{
	if (pause)
	{
		if (gamepad.buttons[7])
		{
			if (do_button_once)
			{
				pause = false;
				do_button_once = false;
			}
		}
		else
		{
			do_button_once = true;
		}
	}
	else
	{
		if (gamepad.buttons[13] || gamepad.axis[0] <= -0.5)
		{
			game_action_left = GameActionLeft::LEFT;
		}
		else
		{
			game_action_left = GameActionLeft::NONE;
		}

		if (gamepad.buttons[11] || gamepad.axis[0] >= 0.5)
		{
			game_action_right = GameActionRight::RIGHT;
		}
		else
		{
			game_action_right = GameActionRight::NONE;
		}

		if (gamepad.buttons[10] || gamepad.axis[1] >= 0.5)
		{
			game_action_up = GameActionUp::UP;
		}
		else
		{
			game_action_up = GameActionUp::NONE;
		}

		if (gamepad.buttons[12] || gamepad.axis[1] <= -0.5)
		{
			game_action_down = GameActionDown::DOWN;
		}
		else
		{
			game_action_down = GameActionDown::NONE;
		}
		if (gamepad.buttons[7])
		{
			if (do_button_once)
			{
				pause = true;
				do_button_once = false;
			}
		}
		else
		{
			do_button_once = true;
		}
	}
}

void InGame::saveScore()
{
	std::ofstream OutFile(".\Resources\scores.txt");
	OutFile << current_level->getLevel();
	OutFile.close();
}


