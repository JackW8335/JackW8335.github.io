#include "stdafx.h"
#include "Furniture.h"

Furniture::Furniture(int furniture_type, float x, float y)
{
	furniture_selected = furniture_type;
	pos.x = x;
	pos.y = y;
}

Furniture::~Furniture()
{
}

bool Furniture::init(ASGE::Renderer * renderer)
{
	

	furniture_1 = renderer->createUniqueSprite();
	if (!furniture_1->loadTexture(".\\Resources\\Textures\\Maps\\furniture_1.png"))
	{
		return false;
	}

	furniture_2 = renderer->createUniqueSprite();
	if (!furniture_2->loadTexture(".\\Resources\\Textures\\Maps\\furniture_2.png"))
	{
		return false;
	}

	furniture_3 = renderer->createUniqueSprite();
	if (!furniture_3->loadTexture(".\\Resources\\Textures\\Maps\\furniture_3.png"))
	{
		return false;
	}

	furniture_4 = renderer->createUniqueSprite();
	if (!furniture_4->loadTexture(".\\Resources\\Textures\\Maps\\furniture_4.png"))
	{
		return false;
	}

	furniture_5 = renderer->createUniqueSprite();
	if (!furniture_5->loadTexture(".\\Resources\\Textures\\Maps\\furniture_5.png"))
	{
		return false;
	}

	furniture_6 = renderer->createUniqueSprite();
	if (!furniture_6->loadTexture(".\\Resources\\Textures\\Maps\\furniture_6.png"))
	{
		return false;
	}

	furniture_7 = renderer->createUniqueSprite();
	if (!furniture_7->loadTexture(".\\Resources\\Textures\\Maps\\furniture_7.png"))
	{
		return false;
	}

	return true;
}

void Furniture::update()
{
	furniture_1->xPos(pos.x + world_pos.x);
	furniture_1->yPos((pos.y - furniture_1->height()) + world_pos.y);
	furniture_2->xPos(pos.x + world_pos.x);
	furniture_2->yPos((pos.y - furniture_2->height()) + world_pos.y);
	furniture_3->xPos(pos.x + world_pos.x);
	furniture_3->yPos((pos.y - furniture_3->height()) + world_pos.y);
	furniture_4->xPos(pos.x + world_pos.x);
	furniture_4->yPos((pos.y - furniture_4->height()) + world_pos.y);
	furniture_5->xPos(pos.x + world_pos.x);
	furniture_5->yPos((pos.y - furniture_5->height()) + world_pos.y);
	furniture_6->xPos(pos.x + world_pos.x);
	furniture_6->yPos((pos.y - furniture_6->height()) + world_pos.y);
	furniture_7->xPos(pos.x + world_pos.x);
	furniture_7->yPos((pos.y - furniture_7->height()) + world_pos.y);
}

void Furniture::render(ASGE::Renderer * renderer, float layer)
{
	switch (furniture_selected)
	{
		case 1:
		{
			renderer->renderSprite(*furniture_1, layer);
			break;
		}
		case 2:
		{
			renderer->renderSprite(*furniture_2, layer);
			break;
		}
		case 3:
		{
			renderer->renderSprite(*furniture_3, layer);
			break;
		}
		case 4:
		{
			renderer->renderSprite(*furniture_4, layer);
			break;
		}
		case 5:
		{
			renderer->renderSprite(*furniture_5, layer);
			break;
		}
		case 6:
		{
			renderer->renderSprite(*furniture_6, layer);
			break;
		}
		case 7:
		{
			renderer->renderSprite(*furniture_7, layer);
			break;
		}
	}
}

ASGE::Sprite * Furniture::getSprite()
{
	switch (furniture_selected)
	{
		case 1:
		{
			return furniture_1.get();
			break;
		}
		case 2:
		{
			return furniture_2.get();
			break;
		}
		case 3:
		{
			return furniture_3.get();
			break;
		}
		case 4:
		{
			return furniture_4.get();
			break;
		}
		case 5:
		{
			return furniture_5.get();
			break;
		}
		case 6:
		{
			return furniture_6.get();
			break;
		}
		case 7:
		{
			return furniture_7.get();
			break;
		}
	}
}

void Furniture::setWorldPos(Vector2 _pos)
{
	world_pos = _pos;
}
