#include "stdafx.h"
#include "Walls.h"

Walls::Walls(int wall_type, float x, float y)
{
	wall_selected = wall_type;
	pos.x = x;
	pos.y = y;
}

Walls::~Walls()
{
}

bool Walls::init(ASGE::Renderer * renderer)
{
	

	wall_top = renderer->createUniqueSprite();
	wall_top->xPos(pos.x);
	wall_top->yPos(pos.y);
	if (!wall_top->loadTexture(".\\Resources\\Textures\\Maps\\wall_top_collide.png"))
	{
		return false;
	}

	wall_mid = renderer->createUniqueSprite();
	wall_mid->xPos(pos.x);
	wall_mid->yPos(pos.y);
	if (!wall_mid->loadTexture(".\\Resources\\Textures\\Maps\\wall_mid_collide.png"))
	{
		return false;
	}

	wall_bot = renderer->createUniqueSprite();
	wall_bot->xPos(pos.x);
	wall_bot->yPos(pos.y);
	if (!wall_bot->loadTexture(".\\Resources\\Textures\\Maps\\wall_bot_collide.png"))
	{
		return false;
	}

	wall_mid_side = renderer->createUniqueSprite();
	wall_mid_side->xPos(pos.x);
	wall_mid_side->yPos(pos.y);
	if (!wall_mid_side->loadTexture(".\\Resources\\Textures\\Maps\\wall_mid_side_collide.png"))
	{
		return false;
	}

	wall_right = renderer->createUniqueSprite();
	wall_right->xPos(pos.x);
	wall_right->yPos(pos.y);
	if (!wall_right->loadTexture(".\\Resources\\Textures\\Maps\\wall_right_collide.png"))
	{
		return false;
	}

	return true;
}

void Walls::update()
{
	wall_top->xPos(pos.x + world_pos.x);
	wall_top->yPos(pos.y + world_pos.y);
	wall_mid->xPos(pos.x + world_pos.x);
	wall_mid->yPos(pos.y + world_pos.y);
	wall_bot->xPos(pos.x + world_pos.x);
	wall_bot->yPos(pos.y + world_pos.y);
	wall_mid_side->xPos(pos.x + world_pos.x);
	wall_mid_side->yPos(pos.y + world_pos.y);
	wall_right->xPos(pos.x + world_pos.x);
	wall_right->yPos(pos.y + world_pos.y);
}

void Walls::render(ASGE::Renderer * renderer, float layer)
{
	switch (wall_selected)
	{
	case 1:
		renderer->renderSprite(*wall_top, layer);
		break;
	case 2:
		renderer->renderSprite(*wall_mid, layer);
		break;
	case 3:
		renderer->renderSprite(*wall_bot, layer);
		break;
	case 4:
		renderer->renderSprite(*wall_mid_side, layer);
		break;
	case 5:
		renderer->renderSprite(*wall_right, layer);
		break;
	}
}

ASGE::Sprite * Walls::getSprite()
{
	switch (wall_selected)
	{
	case 1:
		return wall_top.get();
		break;
	case 2:
		return wall_mid.get();
		break;
	case 3:
		return wall_bot.get();
		break;
	case 4:
		return wall_mid_side.get();
		break;
	case 5:
		return wall_right.get();
		break;
	}
}

void Walls::setWorldPos(Vector2 _pos)
{
	world_pos = _pos;
}
