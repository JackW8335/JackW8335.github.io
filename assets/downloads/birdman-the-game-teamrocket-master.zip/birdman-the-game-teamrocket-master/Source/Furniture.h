#pragma once
#include "GameObject.h"

class Furniture
{
public:
	Furniture(int furniture_type, float x, float y);
	~Furniture();
	bool init(ASGE::Renderer * renderer);
	void update();
	void render(ASGE::Renderer * renderer, float layer);

	ASGE::Sprite* getSprite();

	void setWorldPos(Vector2 _pos);

private:
	Vector2 pos;
	Vector2 world_pos;
	int furniture_selected;

	std::unique_ptr<ASGE::Sprite> furniture_1 = nullptr;
	std::unique_ptr<ASGE::Sprite> furniture_2 = nullptr;
	std::unique_ptr<ASGE::Sprite> furniture_3 = nullptr;
	std::unique_ptr<ASGE::Sprite> furniture_4 = nullptr;
	std::unique_ptr<ASGE::Sprite> furniture_5 = nullptr;
	std::unique_ptr<ASGE::Sprite> furniture_6 = nullptr; 
	std::unique_ptr<ASGE::Sprite> furniture_7 = nullptr;
};