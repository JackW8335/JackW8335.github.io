#pragma once
#include <Engine\Sprite.h>

enum class sideCollided
{
	LEFT,
	UP,
	RIGHT,
	DOWN,
	NONE
};

class BoundingBox 
{
	const sideCollided& collision(const ASGE::Sprite* sprite_box_return_side, const ASGE::Sprite* sprite_box_2);
};