#include "stdafx.h"
#include "Item.h"

Item::Item(int item_type, int x, int y)
{
	item_selected = item_type;
	pos.x = x;
	pos.y = y;
}

Item::~Item()
{
}

bool Item::init(ASGE::Renderer * renderer)
{
	notes = renderer->createUniqueSprite();
	notes->xPos(pos.x);
	notes->yPos(pos.y);
	if (!notes->loadTexture(".\\Resources\\Textures\\Items\\notes.png"))
	{
		return false;
	}

	stopwatch = renderer->createUniqueSprite();
	stopwatch->xPos(pos.x);
	stopwatch->yPos(pos.y);
	if (!stopwatch->loadTexture(".\\Resources\\Textures\\Items\\stopwatch.png"))
	{
		return false;
	}

	batteries = renderer->createUniqueSprite();
	batteries->xPos(pos.x);
	batteries->yPos(pos.y);
	if (!batteries->loadTexture(".\\Resources\\Textures\\Items\\battery_1.png"))
	{
		return false;
	}

	return true;
}

void Item::update()
{
	notes->xPos(pos.x + world_pos.x);
	notes->yPos(pos.y + world_pos.y);
	stopwatch->xPos(pos.x + world_pos.x);
	stopwatch->yPos(pos.y + world_pos.y);
	batteries->xPos(pos.x + world_pos.x);
	batteries->yPos(pos.y + world_pos.y);

}

void Item::render(ASGE::Renderer * renderer, float layer)
{
	switch (item_selected)
	{
	case 1:
		renderer->renderSprite(*notes, layer);
		break;
	case 2:
		renderer->renderSprite(*stopwatch, layer);
		break;
	case 3:
		renderer->renderSprite(*batteries, layer);
		break;
	}
}

ASGE::Sprite * Item::getSprite()
{
	switch (item_selected)
	{
	case 1:
		return notes.get();
		break;
	case 2:
		return stopwatch.get();
		break;
	case 3:
		return batteries.get();
		break;
	}
}

void Item::setPos(float x, float y)
{
	pos.x = x;
	pos.y = y;
}

void Item::setWorldPos(Vector2 _pos)
{
	world_pos = _pos;
}

void Item::randomSpawn()
{
	int rand_x = rand() % 17;
	int rand_y = rand() % 10;
	pos.x = 300 + (rand_x * 100);
	pos.y = 300 + (rand_y * 100);
}

int Item::getItem()
{
	return item_selected;
}

