#pragma once
#include "Level.h"

class Level2 :
	public Level
{
public:
	Level2();
	~Level2();
	// Inherited via Level
	virtual bool init(ASGE::Renderer * renderer) override;
	virtual void update(const ASGE::GameTime &, Player* character, UI* ui, AudioEngine* audio) override;
	virtual void render(ASGE::Renderer * renderer) override;

private:
	void levelInit(ASGE::Renderer * renderer);
	void worldPosUpdate();
	void wallCollision(Player* _player);
	void itemCollision(Player* _player, UI* ui, AudioEngine* audio);
	void furnitureCollision(Player* _player);
	void mobCollision(Player* _player, AudioEngine* audio);
	void addBlob();
	bool collision(ASGE::Sprite* sprite_box, ASGE::Sprite* sprite_box_2);

	Vector2 door_pos;

	bool do_once = true;
	bool play_alert_once = false;
	bool door_open = false;
	int notes = 0;
	int max_notes = 9;
	
	
	std::unique_ptr<ASGE::Sprite> game_background = nullptr;
	std::unique_ptr<ASGE::Sprite> game_walls = nullptr;
	std::unique_ptr<ASGE::Sprite> game_walls_inside = nullptr;
	std::unique_ptr<ASGE::Sprite> door = nullptr;
	std::unique_ptr<ASGE::Sprite> door_open_sprite = nullptr;

	std::vector<std::unique_ptr<Walls>> vec_wall;
	std::vector<std::unique_ptr<Furniture>> vec_furniture;
	std::vector<std::unique_ptr<Blob>> vec_blobs;
	std::vector<std::unique_ptr<Item>> vec_item;

};