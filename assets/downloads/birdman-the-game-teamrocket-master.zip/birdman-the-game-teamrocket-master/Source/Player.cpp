#include "stdafx.h"
#include "Player.h"

namespace
{
	const float PLAYER_RENDER_LAYER = -0.5f;
	const float XRAY_RENDER_LAYER = 0.4f;
	const float centre_screen_x = 1280 / 2;
	const float centre_screen_y = 720 / 2;
};


bool Player::init(ASGE::Renderer * renderer)
{
	speed = 300;
	left_still_sprite = renderer->createUniqueSprite();
	if (!left_still_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_left_still.png"))
	{
		return false;
	}
	left_walk1_sprite = renderer->createUniqueSprite();
	if (!left_walk1_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_left_walk_1.png"))
	{
		return false;
	}
	left_walk2_sprite = renderer->createUniqueSprite();
	if (!left_walk2_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_left_walk_2.png"))
	{
		return false;
	}
	right_still_sprite = renderer->createUniqueSprite();
	if (!right_still_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_right_still.png"))
	{
		return false;
	}
	right_walk1_sprite = renderer->createUniqueSprite();
	if (!right_walk1_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_right_walk_1.png"))
	{
		return false;
	}
	right_walk2_sprite = renderer->createUniqueSprite();
	if (!right_walk2_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_right_walk_2.png"))
	{
		return false;
	}
	sprite = renderer->createUniqueSprite();
	if (!sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_forwards_still.png"))
	{
		return false;
	}
	forwards_walk1_sprite = renderer->createUniqueSprite();
	if (!forwards_walk1_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_forwards_walk_1.png"))
	{
		return false;
	}
	forwards_walk2_sprite = renderer->createUniqueSprite();
	if (!forwards_walk2_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_forwards_walk_2.png"))
	{
		return false;
	}
	back_still_sprite = renderer->createUniqueSprite();
	if (!back_still_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_back_still.png"))
	{
		return false;
	}
	back_walk1_sprite = renderer->createUniqueSprite();
	if (!back_walk1_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_back_walk_1.png"))
	{
		return false;
	}
	back_walk2_sprite = renderer->createUniqueSprite();
	if (!back_walk2_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_back_walk_2.png"))
	{
		return false;
	}
	back_walk2_sprite = renderer->createUniqueSprite();
	if (!back_walk2_sprite->loadTexture(".\\Resources\\Textures\\Character\\cha_back_walk_2.png"))
	{
		return false;
	}
	left_bounding_box = renderer->createUniqueSprite();
	if (!left_bounding_box->loadTexture(".\\Resources\\Textures\\Character\\collision_box_height.png"))
	{
		return false;
	}
	right_bounding_box = renderer->createUniqueSprite();
	if (!right_bounding_box->loadTexture(".\\Resources\\Textures\\Character\\collision_box_height.png"))
	{
		return false;
	}
	top_bounding_box = renderer->createUniqueSprite();
	if (!top_bounding_box->loadTexture(".\\Resources\\Textures\\Character\\collision_box_width.png"))
	{
		return false;
	}
	bot_bounding_box = renderer->createUniqueSprite();
	if (!bot_bounding_box->loadTexture(".\\Resources\\Textures\\Character\\collision_box_width.png"))
	{
		return false;
	}
	pos.x = centre_screen_x + 1 - (sprite->width() / 2);
	pos.y = centre_screen_y + 1 - (sprite->height() / 2);
	return true;
}

void Player::update(const ASGE::GameTime & dt)
{
	controls(dt);
	collision();

	if (timer >= 0.25)
	{
		if (walking_change_animation)
		{
			walking_change_animation = false;
		}
		else
		{
			walking_change_animation = true;
		}
		timer -= 0.25;
	}
	else
	{
		timer += dt.delta_time.count() * 0.001;
	}

	spritePos();
}

void Player::render(ASGE::Renderer * renderer, float layer)
{
	animation(renderer);
	if (render_xray)
	{
		renderer->renderSprite(*left_bounding_box, layer + XRAY_RENDER_LAYER);
		renderer->renderSprite(*right_bounding_box, layer + XRAY_RENDER_LAYER);
		renderer->renderSprite(*top_bounding_box, layer + XRAY_RENDER_LAYER);
		renderer->renderSprite(*bot_bounding_box, layer + XRAY_RENDER_LAYER);
	}
}

ASGE::Sprite * Player::getTopBox()
{
	return top_bounding_box.get();
}

ASGE::Sprite * Player::getLeftBox()
{
	return left_bounding_box.get();
}

ASGE::Sprite * Player::getRightBox()
{
	return right_bounding_box.get();
}

ASGE::Sprite * Player::getBotBox()
{
	return bot_bounding_box.get();
}

void Player::collision()
{
	/*if (pos.x < player_min_x)
	{
		pos.x = player_min_x;
	}
	if (pos.x + sprite->width() > player_max_x)
	{
		pos.x = player_max_x - sprite->width();
	}
	if (pos.y < player_min_y)
	{
		pos.y = player_min_y;
	}
	if (pos.y + sprite->height() > player_max_y)
	{
		pos.y = player_max_y - sprite->height();
	}*/

}

void Player::move(float x, float y)
{
	pos.x += x;
	pos.y += y;
}

void Player::animation(ASGE::Renderer * renderer)
{
	if (character_facing == CharacterFacing::LEFT)
	{
		if (moving)
		{
			if (walking_change_animation)
			{
				renderer->renderSprite(*left_walk1_sprite, PLAYER_RENDER_LAYER);
			}
			else
			{
				renderer->renderSprite(*left_walk2_sprite, PLAYER_RENDER_LAYER);
			}
		}
		else
		{
			renderer->renderSprite(*left_still_sprite, PLAYER_RENDER_LAYER);
		}
	}
	if (character_facing == CharacterFacing::RIGHT)
	{
		if (moving)
		{
			if (walking_change_animation)
			{
				renderer->renderSprite(*right_walk1_sprite, PLAYER_RENDER_LAYER);
			}
			else
			{
				renderer->renderSprite(*right_walk2_sprite, PLAYER_RENDER_LAYER);
			}
		}
		else
		{
			renderer->renderSprite(*right_still_sprite, PLAYER_RENDER_LAYER);
		}
	}
	if (character_facing == CharacterFacing::UP)
	{
		if (moving)
		{
			if (walking_change_animation)
			{
				renderer->renderSprite(*back_walk1_sprite, PLAYER_RENDER_LAYER);
			}
			else
			{
				renderer->renderSprite(*back_walk2_sprite, PLAYER_RENDER_LAYER);
			}
		}
		else
		{
			renderer->renderSprite(*back_still_sprite, PLAYER_RENDER_LAYER);
		}
	}
	if (character_facing == CharacterFacing::DOWN)
	{
		if (moving)
		{
			if (walking_change_animation)
			{
				renderer->renderSprite(*forwards_walk1_sprite, PLAYER_RENDER_LAYER);
			}
			else
			{
				renderer->renderSprite(*forwards_walk2_sprite, PLAYER_RENDER_LAYER);
			}
		}
		else
		{
			renderer->renderSprite(*sprite, PLAYER_RENDER_LAYER);
		}
	}

}

void Player::controls(const ASGE::GameTime & dt)
{
	if (game_action_left == GameActionLeft::LEFT)
	{
		character_facing = CharacterFacing::LEFT;
		moving = true;
	}
	else if (game_action_right == GameActionRight::RIGHT)
	{
		character_facing = CharacterFacing::RIGHT;
		moving = true;
	}
	else if (game_action_up == GameActionUp::UP)
	{
		character_facing = CharacterFacing::UP;
		moving = true;
	}
	else if (game_action_down == GameActionDown::DOWN)
	{
		character_facing = CharacterFacing::DOWN;
		moving = true;
	}
	else
	{
		moving = false;
	}

	if (game_action_x_ray == GameActionXRay::XRAY)
	{
		render_xray = true;
	}
	else
	{
		render_xray = false;
	}

}

void Player::spritePos()
{
	left_still_sprite->xPos(pos.x);
	left_still_sprite->yPos(pos.y);
	left_walk1_sprite->xPos(pos.x);
	left_walk1_sprite->yPos(pos.y);
	left_walk2_sprite->xPos(pos.x);
	left_walk2_sprite->yPos(pos.y);
	right_still_sprite->xPos(pos.x);
	right_still_sprite->yPos(pos.y);
	right_walk1_sprite->xPos(pos.x);
	right_walk1_sprite->yPos(pos.y);
	right_walk2_sprite->xPos(pos.x);
	right_walk2_sprite->yPos(pos.y);
	sprite->xPos(pos.x);
	sprite->yPos(pos.y);
	forwards_walk1_sprite->xPos(pos.x);
	forwards_walk1_sprite->yPos(pos.y);
	forwards_walk2_sprite->xPos(pos.x);
	forwards_walk2_sprite->yPos(pos.y);
	back_still_sprite->xPos(pos.x);
	back_still_sprite->yPos(pos.y);
	back_walk1_sprite->xPos(pos.x);
	back_walk1_sprite->yPos(pos.y);
	back_walk2_sprite->xPos(pos.x);
	back_walk2_sprite->yPos(pos.y);

	left_bounding_box->xPos(pos.x - 1);
	left_bounding_box->yPos(pos.y + 6);

	top_bounding_box->xPos(pos.x + 4);
	top_bounding_box->yPos(pos.y - 1);

	right_bounding_box->xPos(pos.x + (sprite->width() - 1));
	right_bounding_box->yPos(pos.y + 6);

	bot_bounding_box->xPos(pos.x + 4);
	bot_bounding_box->yPos(pos.y + (sprite->height() - 1));



}
