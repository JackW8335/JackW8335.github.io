#pragma once
#include "GameState.h"
#include "Player.h"
#include "Walls.h"
#include "Furniture.h"
#include "Blob.h"
#include "UI.h"
#include "DeltaTime.h"
#include "Item.h"
#include "Sound.h"
#include "Level.h"

class InGame :
	public GameState
{
public:
	InGame();
	~InGame();
	// Inherited via GameState
	virtual bool init(ASGE::Renderer * renderer) override;
	void saveScore();
	virtual void update(const ASGE::GameTime &, const GamePadData & gamepad, ASGE::Renderer * renderer) override;
	virtual void render(ASGE::Renderer * renderer) override;
	virtual void keyHandler(int key, int action) override;
	
private:
	DeltaTime deltaTime;
	

	virtual void controller(const GamePadData & gamepad) override;
	void moveMap(const ASGE::GameTime & dt);
	void move(float x, float y);
	void worldPos();
	void timer(const ASGE::GameTime &);
	
	bool pause = false;

	Vector2 world_pos;
	bool x_ray = false;
	bool load_level_2 = true;
	float speed = 300;
	int notes = 0;
	double timer_second = 0;
	double timer_step = 0;
	double seconds = 59;
	double minutes = 2;

	float area_min_x = 430;
	float area_max_x = -1765;
	float area_min_y = 140;
	float area_max_y = -850;

	std::unique_ptr<ASGE::Sprite> pause_background = nullptr;

	std::unique_ptr<Level> current_level;
	std::unique_ptr<Player> character = nullptr;
	std::unique_ptr<UI> ui = nullptr;
	std::unique_ptr<AudioEngine> audio = nullptr;


};