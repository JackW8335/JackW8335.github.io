#pragma once
#include "GameState.h"

class Pause :
	public GameState
{
public:
	Pause();
	~Pause();

	// Inherited via GameState
	virtual bool init(ASGE::Renderer * renderer) override;
	virtual void update(const ASGE::GameTime &, const GamePadData & gamepad, ASGE::Renderer * renderer) override;
	virtual void render(ASGE::Renderer * renderer) override;
	virtual void keyHandler(int key, int action) override;

private:
	virtual void controller(const GamePadData & gamepad) override;

	std::unique_ptr<ASGE::Sprite> pause_background = nullptr;

};