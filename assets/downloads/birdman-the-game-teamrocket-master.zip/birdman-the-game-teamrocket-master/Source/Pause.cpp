#include "Pause.h"

Pause::Pause()
{
	do_button_once = false;
}

Pause::~Pause()
{
}

bool Pause::init(ASGE::Renderer * renderer)
{
	
	return true;
}

void Pause::update(const ASGE::GameTime &, const GamePadData & gamepad, ASGE::Renderer * renderer)
{
	if (gamepad.is_connected)
	{
		controller(gamepad);
	}
}

void Pause::render(ASGE::Renderer * renderer)
{
	renderer->renderSprite(*pause_background, -2);
}

void Pause::keyHandler(int key, int action)
{
	if (action == ASGE::KEYS::KEY_PRESSED)
	{
		if (key == ASGE::KEYS::KEY_ESCAPE)
		{
			game_state = GameStates::GAME;
		}
	}
}

void Pause::controller(const GamePadData & gamepad)
{
	if (gamepad.buttons[7])
	{
		if (do_button_once)
		{
			game_state = GameStates::GAME;
		}
		do_button_once = false;
	}
	else
	{
		do_button_once = true;
	}
}
