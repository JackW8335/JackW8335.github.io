#include "stdafx.h"
#include "BoundingBox.h"

const sideCollided & BoundingBox::collision(const ASGE::Sprite * sprite_box_return_side, const ASGE::Sprite * sprite_box_2)
{
	float sprite_1_bottom = sprite_box_return_side->yPos() + sprite_box_return_side->height();
	float sprite_2_bottom = sprite_box_2->yPos() + sprite_box_2->height();
	float sprite_1_right = sprite_box_return_side->xPos() + sprite_box_return_side->width();
	float sprite_2_right = sprite_box_2->xPos() + sprite_box_2->width();

	float b_collision = sprite_2_bottom - sprite_box_return_side->yPos();
	float t_collision = sprite_1_bottom - sprite_box_2->yPos();
	float l_collision = sprite_1_right - sprite_box_2->xPos();
	float r_collision = sprite_2_right - sprite_box_return_side->xPos();

	if (t_collision < b_collision && t_collision < l_collision && t_collision < r_collision)
	{
		return sideCollided::UP;
	}
	if (b_collision < t_collision && b_collision < l_collision && b_collision < r_collision)
	{
		return sideCollided::DOWN;
	}
	if (l_collision < r_collision && l_collision < t_collision && l_collision < b_collision)
	{
		return sideCollided::LEFT;
	}
	if (r_collision < l_collision && r_collision < t_collision && r_collision < b_collision)
	{
		return sideCollided::RIGHT;
	}
	return sideCollided::NONE;
}