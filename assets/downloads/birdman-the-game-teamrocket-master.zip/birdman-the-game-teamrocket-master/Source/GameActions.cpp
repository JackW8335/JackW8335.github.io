#include "GameActions.h"

std::atomic<GameStates> game_state = GameStates::MENU;
std::atomic<GameActionLeft> game_action_left = GameActionLeft::NONE;
std::atomic<GameActionRight> game_action_right = GameActionRight::NONE;
std::atomic<GameActionUp> game_action_up = GameActionUp::NONE;
std::atomic<GameActionDown> game_action_down = GameActionDown::NONE;
std::atomic<GameActionXRay> game_action_x_ray = GameActionXRay::NONE;
std::atomic<CharacterFacing> character_facing = CharacterFacing::DOWN;
std::atomic<MenuButton> menu_button = MenuButton::NONE;
std::atomic<EnemyState> enemy_state = EnemyState::ROAM;
std::atomic<Cinematic> cinematic = Cinematic::NONE;