var searchData=
[
  ['opacity',['opacity',['../class_a_s_g_e_1_1_sprite.html#a4c4d114fe0cc99dcd25838882b145e92',1,'ASGE::Sprite::opacity(float alpha)'],['../class_a_s_g_e_1_1_sprite.html#a865f65d855f1fee3e5cf522f5b1dbeba',1,'ASGE::Sprite::opacity() const']]],
  ['operator_3d',['operator=',['../class_non_copyable.html#a45fb2777525bd4a6841783a9e37db837',1,'NonCopyable']]]
];
