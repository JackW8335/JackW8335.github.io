var searchData=
[
  ['init',['init',['../class_a_s_g_e_1_1_game.html#a53a1b2f02a4a0df1402a2770d40868d4',1,'ASGE::Game::init()'],['../class_a_s_g_e_1_1_input.html#ad9af0281184f2a2a053cf12187bdd9d6',1,'ASGE::Input::init()'],['../class_a_s_g_e_1_1_renderer.html#acb87c2764b8322e9f775acee97c78ad4',1,'ASGE::Renderer::init()']]],
  ['initapi',['initAPI',['../class_a_s_g_e_1_1_game.html#a540469ded5f13abda34897fdfd22b6de',1,'ASGE::Game::initAPI()'],['../class_a_s_g_e_1_1_o_g_l_game.html#ad105b03f241a25b9b31a343e088a3383',1,'ASGE::OGLGame::initAPI()']]],
  ['input',['Input',['../class_a_s_g_e_1_1_input.html#a847719fb169e39a9e21b309253f5c496',1,'ASGE::Input']]],
  ['inputptr',['inputPtr',['../class_a_s_g_e_1_1_renderer.html#a883f91a1cc580568ba2c401abb954cb4',1,'ASGE::Renderer']]],
  ['isflippedonx',['isFlippedOnX',['../class_a_s_g_e_1_1_sprite.html#ad9172940b3ea2dfc1c1d359b41479515',1,'ASGE::Sprite']]],
  ['isflippedony',['isFlippedOnY',['../class_a_s_g_e_1_1_sprite.html#af395335611d84b573ed23d3d04214f7f',1,'ASGE::Sprite']]]
];
