var searchData=
[
  ['noncopyable',['NonCopyable',['../class_non_copyable.html#a809b6e4ade7ae32f6d248f2a3b783d45',1,'NonCopyable::NonCopyable()=default'],['../class_non_copyable.html#a52b8dd9433311afe24bd244a9d8e9a90',1,'NonCopyable::NonCopyable(NonCopyable const &amp;)=delete']]]
];
