var searchData=
[
  ['xoffset',['xoffset',['../struct_a_s_g_e_1_1_scroll_event.html#a6e0f8e30ca98529d1fc08242d1043b20',1,'ASGE::ScrollEvent']]],
  ['xpos',['xpos',['../struct_a_s_g_e_1_1_move_event.html#a69fa63a85ccf2a233cb84cfc60345031',1,'ASGE::MoveEvent']]]
];
