var searchData=
[
  ['violet',['VIOLET',['../namespace_a_s_g_e_1_1_c_o_l_o_u_r_s.html#aa46b6b358c84f2f7ee610f48a8f0d12d',1,'ASGE::COLOURS']]]
];
