var searchData=
[
  ['sharedeventdata',['SharedEventData',['../namespace_a_s_g_e.html#aa98ce31de963e1cacff2c4aa4a06c70e',1,'ASGE']]]
];
