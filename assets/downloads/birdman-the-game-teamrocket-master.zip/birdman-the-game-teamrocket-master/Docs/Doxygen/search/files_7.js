var searchData=
[
  ['platform_2eh',['Platform.h',['../_platform_8h.html',1,'']]]
];
